using System;
using log4net;
using log4net.Repository;

namespace UseDynLog4net
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
      private static readonly ILog logger = LogManager.GetLogger(typeof(Class1));
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
         // define layouts
         log4net.Layout.PatternLayout layout1 = new log4net.Layout.PatternLayout("|1|%d [%t] %-5p %c - %m%n");
         log4net.Layout.PatternLayout layout2 = new log4net.Layout.PatternLayout("|2|%d [%t] %-5p %c - %m%n");
         layout1.Header="-- Session %d--\n";
         layout2.Header="-- Session %d--\n";


         // define file appender 1
         log4net.Appender.FileAppender fa = new log4net.Appender.FileAppender();
         fa.File = "UseDynLog4net.txt";
         fa.AppendToFile=true;
         fa.Layout = layout1;
         fa.ActivateOptions();
         

         // define file appender 2
         log4net.Appender.FileAppender fa2 = new log4net.Appender.FileAppender();
         fa2.File="file2.txt";
         fa2.Layout=layout1;
         fa2.ActivateOptions();

         // add appenders to rep
         
         ILoggerRepository aRepos = logger.Logger.Repository;
         log4net.Repository.Hierarchy.Hierarchy hir = ((log4net.Repository.Hierarchy.Hierarchy)aRepos);
			hir.ResetConfiguration();
         hir.Root.AddAppender(fa);
         hir.Root.AddAppender(fa2);

			

         // config
         log4net.Config.BasicConfigurator.Configure(hir);

         logger.Info("Hi 1");

         logger.Info("Hi 2");

         log4net.Appender.IAppender ia = hir.Root.GetAppender("");
         hir.Root.Level = log4net.Core.Level.Debug;
         
        

		}
	}
}
