﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;

namespace Tester
{
   class Program
   {
      static void Main(string[] args)
      {
         string[] ports = SerialPort.GetPortNames();

         // Add all port names to the combo box:
         foreach (string port in ports)
         {
            Console.WriteLine(port);
         }

         SerialPort rs232port = new SerialPort("COM1");
         rs232port.Open();
         if (rs232port.IsOpen)
         {
            //rs232port.Write((new byte[] { 1, 2, 3 }), 0, 3);
            byte [] inBuf = new byte[10];
            // rs232port.Read( inBuf, 0, 10); // blocking
            //rs232port.ReadByte();// blocking
            string s = rs232port.ReadExisting(); // non blocking. empty string "" returns if there is nothing
            rs232port.Close();
         }

         //rs232port.BaseStream
      }
   }
}
