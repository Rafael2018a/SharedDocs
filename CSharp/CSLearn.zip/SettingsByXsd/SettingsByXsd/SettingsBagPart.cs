﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using LogShell;


namespace MyNamespace
{

   partial class SettingsBag
   {
      private static SettingsBag _instance;

      private SettingsBag() { }

      object lockObject = new object();
      static ILogShell m_logger = Log4NetImp.GetLogger("SettingsBag", LogDebugColor.BlueBold);
      const string m_settingsFilename = @"..\CFG\Settings.xml";
      const string m_settingsSampleFilename = "Settings.Sample.xml";
      public static SettingsBag Instance
      {
         get
         {
            if (_instance == null) // (why lock for nothing)
               lock (typeof(SettingsBag))
               {
                  if (_instance == null) // must check again
                  {
                     SettingsBag sb = LoadInstanceFromFile();
                     if (sb == null)
                     {
                        _instance = new SettingsBag();
                        _instance.InitNewInstance();
                     }
                     else
                        _instance = sb;
                  }
               }
            return _instance;
         }
      }

      private static SettingsBag LoadInstanceFromFile()
      {
         SettingsBag resutlInstance = null;
         FileInfo fi = new FileInfo(m_settingsFilename);
         try
         {
            using (FileStream fs = fi.OpenRead()) //new FileStream(m_settingsFilename, FileMode.Open, FileAccess.Read))
            {
               XmlSerializer xs = new XmlSerializer(typeof(SettingsBag));
               resutlInstance = (SettingsBag)xs.Deserialize(fs);
            }
            m_logger.Info("Settings successfully loaded from file {0}", fi.FullName);
         }
         catch (Exception ex) // FileNotFound or InvalidOperationException (type mismatch)
         {
            m_logger.Error("Can't load settings file {0}. {1}", fi.FullName, ex.Message);
         }

         return resutlInstance;
      }

      private void InitNewInstance()
      {
         try
         {
            // creare instances (must!)
            this.Section1 = new SettingsBagSection1();
            this.Section2 = new SettingsBagSection2();
            this.Section2.elementWithAttr = new SettingsBagSection2ElementWithAttr();

            // set default values
            this.Section1.val1 = "ddd";
            this.Section2.threeinaboat = 11;
            this.Section2.elementWithAttr.PossibleValues = "abc";
            this.Section2.elementWithAttr.Value = "value1";

            // save sample file
            FileInfo fi = new FileInfo(m_settingsSampleFilename);
            using (FileStream fs = fi.OpenWrite())
            {
               XmlSerializer xs = new XmlSerializer(typeof(SettingsBag));// cbag.GetType());
               xs.Serialize(fs, this);
            }
            m_logger.Info("Default values applied to all settings. Sample file created {0}", fi.FullName);
         }
         catch (Exception ex)
         {
            m_logger.Error(ex.ToString());
         }
      }

   }

}
