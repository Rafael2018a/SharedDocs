﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyNamespace;

namespace SettingsByXsd
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run2();

      }

      private void Run2()
      {
         string s = SettingsBag.Instance.Section1.val1;
         sbyte sb = SettingsBag.Instance.Section2.threeinaboat;
      }

   }


}

