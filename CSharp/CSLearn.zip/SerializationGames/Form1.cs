using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;

namespace SerializationGames
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         BinMessage theObj = new BinMessage();

         string s = "hello";
         theObj.vector = Encoding.ASCII.GetBytes(s.ToCharArray());


         FileStream fs = File.Create("myfile.bin");
         BinaryFormatter bf = new BinaryFormatter();
         bf.Serialize(fs, theObj);
         bf.Serialize(fs, s);
         fs.Close();


      }

      private void button2_Click(object sender, EventArgs e)
      {
         FileStream fs = File.OpenRead("myfile.bin");

         BinaryFormatter bf = new BinaryFormatter();
         BinMessage theObj;
         string s;
         using (fs)
         {
            theObj = (BinMessage)bf.Deserialize(fs);
            s = (string)bf.Deserialize(fs);
         }
         byte b = theObj.notToSerialize;
      }

      private void button_serializeWithSoap_Click(object sender, EventArgs e)
      {
         using (FileStream fs = new FileStream("object.xml", FileMode.Create, FileAccess.Write) )
         {
            SoapFormatter sf = new SoapFormatter();
            SomeClass sc = new SomeClass();
            System.Threading.Monitor.Enter(sc);
            System.Threading.Monitor.Exit(sc);
            sf.Serialize( fs, sc);
         }
         
      }
      [Serializable]
      class SomeClass
      {
         int xyz;
      }
   }

   [Serializable]
   class BinMessage: System.Runtime.Serialization.IDeserializationCallback
   {
      public byte[] vector;
      public byte status;
      [NonSerialized]
      public byte notToSerialize;



      public void OnDeserialization(object sender)
      {
         notToSerialize = 17;
      }


   }

}