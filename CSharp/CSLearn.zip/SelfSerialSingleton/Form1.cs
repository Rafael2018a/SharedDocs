using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace SelfSerialSingleton
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         int a = selfSetSingleton.Instance.val;
         selfSetSingleton.Instance.dosomething();
         selfSetSingleton.Instance.val = 10;
      }
   }

   public class selfSetSingleton
   {
      public int val;
      private  selfSetSingleton() { }
      private static selfSetSingleton _instance=null;
      public static selfSetSingleton Instance
      {
         get
         {

            if (_instance == null)
            {
               FileInfo fi = new FileInfo("sss.ser");
               if (fi.Exists)
               {
                  FileStream fs = fi.OpenRead();
                  BinaryFormatter bf = new BinaryFormatter();
                  _instance = (selfSetSingleton)bf.Deserialize(fs);
                  fs.Close();
               }
               else
               _instance = new selfSetSingleton();
            }
            return _instance;
         }
      }

      public int dosomething()
      {
         int a = 0;
         return a;
      }

      ~selfSetSingleton() 
      {
         FileStream fs = new FileStream("sss.ser", FileMode.Create, FileAccess.Write);
         BinaryFormatter bf = new BinaryFormatter();
         bf.Serialize(fs, _instance);
         fs.Close();
      }
   }
}