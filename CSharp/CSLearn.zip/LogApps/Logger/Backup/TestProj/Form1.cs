using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using LogLib;
using System.IO;

namespace TestProj
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         
      }

      private void button1_Click_1(object sender, EventArgs e)
      {
         FileInfo fi = new FileInfo("kkk");
         try
         {
            fi.CopyTo("kkkk");
         }
         catch (Exception ex)
         {
            string s = ex.ToString();
            //string s1 = s.Replace(Char.ConvertFromUtf32(0x0D), "-");
            Logger.Instance.Info(s);
         }

        
      }


   }
}
