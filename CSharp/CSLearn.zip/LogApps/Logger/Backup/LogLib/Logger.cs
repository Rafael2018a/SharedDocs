using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using log4net;

namespace LogLib
{
   public class Logger
   {
      private Logger()
      {
         log4net.Config.XmlConfigurator.Configure();
         _log4netLogger = LogManager.GetLogger("MXfrManager");

         //m_clientLogger = LogManager.GetLogger("ClientLogger"); // this is an activity logger according to client request

         //log4net.Appender.FileAppender appender = new log4net.Appender.FileAppender();
         //log4net.Layout.PatternLayout layout = new log4net.Layout.PatternLayout("[%date] %message %newline");
         
         //appender.File = "clinetlogfile.log.txt";
         //appender.AppendToFile=true;

         //appender.Layout = layout;
         //appender.ActivateOptions();
         //log4net.Config.BasicConfigurator.Configure(appender);

      }
      private static object lockObject = new object();
      private readonly ILog _log4netLogger;// = LogManager.GetLogger( "MXfrManager" );
      //private readonly ILog m_clientLogger;// = LogManager.GetLogger( "MXfrManager" );
      private static Logger _instance;
      public static Logger Instance
      {
         get
         {
            lock (lockObject)
            {
               if (_instance == null)
                  _instance = new Logger();
            }
            return _instance;
         }
      }

      private void WriteLogLine(int level, string formatString, params object[] args)
      {
         StackFrame callerFrame = new StackFrame(2, true);
         DateTime dt = DateTime.Now;
         string message = string.Format(formatString, args);

         // remove new-line from string (this is for EltaLog)
         message = message.Replace('\n', '-');
         message = message.Replace('\r', '-');

         string objectType = callerFrame.GetMethod().ReflectedType.Name;

         string enhancedMessage = string.Format("({0}.{1}, Line#{2}) {3}", objectType, callerFrame.GetMethod().Name, callerFrame.GetFileLineNumber(), message);
         _log4netLogger.Info(string.Format("|{0}|{1}|{2}|{3}|{4}|", level, dt.ToShortDateString(), dt.ToShortTimeString(), enhancedMessage, objectType));

      }
      public void Error(string formatString, params object[] args)
      {
         StackFrame callerFrame = new StackFrame(1, true);

         lock (_log4netLogger)
         {
            WriteLogLine(0, formatString, args);
         }
      }

      public void Warn(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(1, formatString, args);
         }
      }

      public void Info(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(2, formatString, args);
         }
      }

      public void Debug(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(3, formatString, args);
         }
      }


      public void WriteClientLogEntry(LogEntry entry)
      {
         // get details
         DateTime dt = DateTime.Now;

         string logFilename = BuildLogFilename(dt);
         FileInfo fi = new FileInfo(logFilename);
         //if (!Directory.Exists(fi.DirectoryName))
         //{
         //   Logger.Instance.Error("Directory {0} does not exists. Line NOT added to sip file", fi.DirectoryName);
         //   rc = false;
         //   goto exit;
         //}

         FileStream fStream;
         try
         {
            fStream = fi.Open(FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
         }
         catch (Exception ex)
         {
            Logger.Instance.Error("Could not open client log file {0} for writing; {1}", fi.FullName, ex.Message);
            goto exit;
         }
         // goto end of file
         fStream.Seek(0, SeekOrigin.End);
         StreamWriter sWriter = new StreamWriter(fStream);

         string WorkLogLine = String.Format("[{0}, User:{1}] {2}. {3}", dt.ToString("yyyy-MM-dd HH:mm:ss"), System.Environment.UserName, entry.EntryType.ToString(), entry.Message);
         sWriter.WriteLine(WorkLogLine);

         sWriter.Close();
         fStream.Close();

         exit: return;
      }

      private string BuildLogFilename(DateTime dt)
      {
         //string fullFileName = null;

         string dateString = dt.ToString("MMMyyyy");

         string fileName = "Log_"+dateString + ".txt";

         return fileName;
      }

   }

   public class LogEntry
   {
      LogEntryType m_logType;

      public LogEntryType EntryType
      {
         get { return m_logType; }
      }

      string m_message;
      public string Message {get { return m_message; } }

      int m_intValue;
      public int IntValue  {  get { return m_intValue; } }

      long m_longValue;
      public long longValue { get { return m_longValue; } }

      //DateTime m_timestamp;

      //public DateTime Timestamp
      //{
      //   get { return m_timestamp; }
      //}

      public LogEntry(string _message, int _intValue, long _longValue, LogEntryType _logType)
      {
         m_message = _message;
         m_intValue = _intValue;
         m_longValue = _longValue;
         //         m_timestamp = timestamp;
         m_logType = _logType;
      }
   }

   public enum LogEntryType { File_Transferred, File_Transferred_Manually, File_Deleted_On_Remote, File_Deleted_On_Local, Connection_Established, Program_Started };
}
