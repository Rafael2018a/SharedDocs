﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using System.Xml.Linq;

namespace LogReceiver
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run();
      }

      void Run()
      {
         UdpClient udpc = new UdpClient(8989);
         IPEndPoint ep = null;

         while (true)
         {
            byte[] logMessage = udpc.Receive(ref ep);
            string s = System.Text.Encoding.Default.GetString(logMessage);

            // simple print
            Console.WriteLine(s);

         }

      }
   }
}
