using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Xml;

namespace SocketServer
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         //p.TcpServer();
         p.UdpServer();


      }

      void UdpServer()
      {
         int numberOfReceivedBytes;
         byte[] data = new byte[1024];

#if anyIp
            //IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 8000);
#else // uniq local ip
         //string hostName = Dns.GetHostName();
         //IPHostEntry localHostEntry = Dns.GetHostEntry(hostName);
         //int c = localHostEntry.AddressList.Length;

         IPAddress localIpAddress = IPAddress.Parse("127.0.0.1");  //localHost.AddressList[0];
         IPEndPoint localEp = new IPEndPoint(localIpAddress, 8989);
#endif
         Socket sock1 = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
         sock1.Bind(localEp); // must call this before ReceiveFrom()
         Console.WriteLine("Waiting for a client (On all network interfaces. Port=8989) ...");

         EndPoint remoteEp = (EndPoint)(new IPEndPoint(IPAddress.Any, 0)); // IPAddress.Any=0.0.0.0

         numberOfReceivedBytes = sock1.ReceiveFrom(data, ref remoteEp);

         string message = Encoding.ASCII.GetString(data, 0, numberOfReceivedBytes);
         Console.WriteLine("Message {0}\n===received from {1}:", message, remoteEp.ToString());

         //System.IO.FileStream fs = new System.IO.FileStream("message.xml", System.IO.FileMode.Create, System.IO.FileAccess.Write);
         //System.IO.StreamWriter sw = new System.IO.StreamWriter(fs);
         //sw.WriteLine(message);
         //sw.Close();
         //fs.Close();

         XmlDocument xDoc = new XmlDocument();

         xDoc.LoadXml(message);


         XmlNodeList xList = xDoc.ChildNodes;
         foreach (XmlNode xn1 in xList)
         {
            Console.WriteLine(xn1.InnerXml);
         }
         //XmlWriter xWriter = XmlWriter.Create("message.xml");
         //xDoc.WriteTo( xWriter);
         //xWriter.Close();
         //Console.WriteLine();
         XmlNode root = xDoc.FirstChild;
         XmlAttributeCollection ac = root.Attributes;
         foreach (XmlAttribute ar in ac)
         {
            Console.Write(ar.Name+" = ");
            Console.WriteLine(ar.Value);
         }

         Console.ReadKey();
         // send reply
         //string welcome = "Welcome to my test server";
         //data = Encoding.ASCII.GetBytes(welcome);
         //sock1.SendTo(data, data.Length, SocketFlags.None, remoteEp);
      }

      void TcpServer()
      {
         string hostName = Dns.GetHostName();
         IPHostEntry localHost = Dns.GetHostEntry(hostName);
         //IPHostEntry localHost = Dns.GetHostByName( hostName);
         int c = localHost.AddressList.Length;
         IPAddress localIpAddress = localHost.AddressList[0];
         IPEndPoint localEp = new IPEndPoint(localIpAddress, 8000);

         Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
         serverSocket.Bind(localEp);


         serverSocket.Listen(5);
         Socket inSocket = serverSocket.Accept();

         string receivedMessage;
         int i = 0;
         do
         {
            byte[] buf = new byte[256];
            int count = inSocket.Receive(buf);
            try
            {
               receivedMessage = Encoding.UTF8.GetString(buf, 0, count);
            }
            catch (Exception ex)
            {
               Console.WriteLine(ex.Message);
               goto exit;
            }
            Console.WriteLine(receivedMessage);
            if (receivedMessage == "bye")
               break;

            byte[] reply = Encoding.UTF8.GetBytes(string.Format("OK {0}", i++));
            inSocket.Send(reply);

         } while (true);

         byte[] reply1 = Encoding.UTF8.GetBytes("goodbye");
         inSocket.Send(reply1);
         //reply1 = Encoding.UTF8.GetBytes("goodbye2");
         //theclientSocket.Send(reply1);

         inSocket.Shutdown(SocketShutdown.Both);
         inSocket.Close();

         //theserver.Shutdown(SocketShutdown.Both);
         serverSocket.Close();

         exit: return;
      }
   }
}
