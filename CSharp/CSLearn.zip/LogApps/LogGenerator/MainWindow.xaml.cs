﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using log4net;

namespace LogGenerator
{
   public partial class MainWindow : Window
   {
      public MainWindow()
      {
         InitializeComponent();
      }

      ILog m_mainLogger;// = LogManager.GetLogger("MainLogger");
      System.Timers.Timer m_timer = new System.Timers.Timer(1000.0);
      int m_messageCounter = 0;

      private void Window_Loaded(object sender, RoutedEventArgs e)
      {
         log4net.Config.XmlConfigurator.Configure();
         m_mainLogger = LogManager.GetLogger("MainLogger");
         m_timer.Elapsed += new System.Timers.ElapsedEventHandler(m_timer_Elapsed);
      }

      void m_timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
      {
         m_mainLogger.Info( string.Format( "Log message {0}", m_messageCounter ));
      }

      private void botton_start_Click(object sender, RoutedEventArgs e)
      {
         m_timer.Enabled = true;
      }

      private void botton_stop_Click(object sender, RoutedEventArgs e)
      {
         m_timer.Enabled = false;
      }
   }
}
