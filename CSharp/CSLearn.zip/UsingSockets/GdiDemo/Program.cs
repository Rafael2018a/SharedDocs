﻿//#define method1
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Collections;

namespace GdiDemo
{
   class Program
   {
      static void Main(string[] args)
      {
         if (args.Length == 1)
         {
            IPAddress ip = IPAddress.Parse(args[0]);
            Program p = new Program();
            p.Run(ip);
         }
         else
         {
            Console.WriteLine("Usage: GdiDemo IPString (example: > GdiDemo 128.139.71.82)");
            Console.ReadLine();
         }
      }



      Socket m_localSocket;
      //IPAddress m_remoteIp;
//      Sysroot.MultiLogger.ILogger m_logger = Sysroot.MultiLogger.LogManager.EltaLogger;
      bool m_ThreadStopRequestFlag = false;
      byte[] m_tcpInputBuffer = new byte[65536];
      byte[] m_inputBuffer = new byte[655360];// 131072];
      //byte[] m_tempBuffer = new byte[655360];// 131072];
      int m_bufferCopyPoint = 0;
      int m_bufferStartPoint = 0;
      //long m_absolutebufferStartPoint = 0;
      long m_totalBytesReadFromTcp = 0;
      const int m_preambleSegmentLength = 8;
      int m_messageCounter = 0;
      byte[] m_preambleSegmentStartBytes = { 0x41, 0x0c };
      byte[] m_messageSegmentStartBytes = { 0xAC, 0x13 };

      /// <summary>
      /// Gdi as tcp-client. Gdi is a receiver
      /// </summary>
      private void Run( IPAddress remoteIp)
      {
         m_logger.LogLevel = Sysroot.MultiLogger.LogLevel.INFO;
         m_logger.Debug("debug");
         do
         {
            m_localSocket = OpenTcpChannelAsClient( remoteIp);
            try
            {
               MessageLoop1();
            }
            catch (Exception ex)
            {
               m_logger.Error(ex.ToString());
            }
            finally
            {
               m_logger.Info("Closing tcp channel");
               CloseTcpChannel(m_localSocket);
            }
         } while (m_ThreadStopRequestFlag == false);
      }

      private void CloseTcpChannel(Socket m_localSocket)
      {
         m_localSocket.Close();
      }



      private Socket OpenTcpChannelAsClient( IPAddress remoteIp)
      {
         IPEndPoint ep = new IPEndPoint( remoteIp, 4567);
         Socket newSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
         while (true)
         {
            try
            {
               newSocket.Connect(ep);
               m_logger.Info( string.Format("Connection established with {0}", ep.ToString()));
               break;
            }
            catch (SocketException se)
            {
               m_logger.Warn(se.Message);
               System.Threading.Thread.Sleep(1000);
            }
         }

         return newSocket;
      }

      void MessageLoop1()
      {
         // init
         m_bufferCopyPoint = 0;
         m_bufferStartPoint = 0;
         m_messageCounter = 0;
         m_totalBytesReadFromTcp = 0;

         // loop
         int numberOfReceivedByts = 0;
         ArrayList messageVector;
         while (true)
         {
            numberOfReceivedByts =  MoveFromTcpToInputBuffer();
            if (numberOfReceivedByts > 0)
            {
               messageVector = MessageParser();
               //if (messageVector.Count > 0)
               // Enqueue(messageVector); to GirWorker
               GarbageCollect();
            }
            else
               break; // loop (remote disconnected)
         }
      }

      private void GarbageCollect()
      {
         Buffer.BlockCopy(m_inputBuffer, m_bufferStartPoint, m_inputBuffer, 0, m_bufferCopyPoint - m_bufferStartPoint);
         m_bufferCopyPoint -= m_bufferStartPoint;
         m_logger.Debug( string.Format("GarbageCollect: Shift of {0} bytes. New CopyPoint={1}. TotalBytesReadFromTcp={2}", m_bufferStartPoint, m_bufferCopyPoint, m_totalBytesReadFromTcp));
         m_bufferStartPoint = 0;
         //throw new NotImplementedException();
      }
      enum SeekState { Searching, Locating };
      SeekState m_seekState = SeekState.Searching;

      /// <summary>
      /// Go over inputBuffer, throw away 8-byte-preambles, and return vector of messages
      /// </summary>
      /// <returns></returns>
      private ArrayList MessageParser()
      {
         bool loopBreakFlag = false;
         //int offset;
         
         int preambleCounter = 0;

         ArrayList resultList = new ArrayList();

         do
         {
            switch (m_seekState)
            {
               case SeekState.Searching: // => bufferStartPoint is not bound to segment
                  {
                     int bufferOffset = BufferBlindSeek(m_bufferStartPoint, m_bufferCopyPoint);
                     System.Diagnostics.Debug.Assert( bufferOffset >= 0);
                     System.Diagnostics.Debug.Assert( bufferOffset <= m_bufferCopyPoint);
                     if (bufferOffset < (m_bufferCopyPoint - 1)) 
                     {
                        m_seekState = SeekState.Locating;
                        m_logger.Debug(string.Format("SeekState={0}", m_seekState));
                     }
                     else // => message not found or ac/41 in last byte
                        loopBreakFlag = true; // more data needed in inputBuffer

                     
                     m_bufferStartPoint = bufferOffset;
                     
                     System.Diagnostics.Debug.Assert(m_bufferStartPoint <= m_bufferCopyPoint);
                  }
                  break;

               case SeekState.Locating: // => bufferStartPoint is bound to segment
                  {
                     if (m_inputBuffer[m_bufferStartPoint] == m_preambleSegmentStartBytes[0]) // preamble
                     {
                        System.Diagnostics.Debug.Assert(m_inputBuffer[m_bufferStartPoint + 1] == m_preambleSegmentStartBytes[1]);
                        if ((m_bufferCopyPoint - m_bufferStartPoint) > 8)
                        {
                           m_bufferStartPoint += m_preambleSegmentLength;
                           
                           System.Diagnostics.Debug.Assert(m_bufferStartPoint < m_bufferCopyPoint);
                        }
                        else
                           loopBreakFlag = true; // more data needed in inputBuffer
                     }
                     else
                        if (m_inputBuffer[m_bufferStartPoint] == m_messageSegmentStartBytes[0]) // message
                        {
                           System.Diagnostics.Debug.Assert(m_inputBuffer[m_bufferStartPoint + 1] == m_messageSegmentStartBytes[1]);
                           short nominalMessageLength = BitConverter.ToInt16(m_inputBuffer, m_bufferStartPoint + 2);

                           if ((m_bufferCopyPoint - m_bufferStartPoint) > nominalMessageLength)
                           {
                              byte[] tempBuffer = new byte[nominalMessageLength];
                              Buffer.BlockCopy(m_inputBuffer, m_bufferStartPoint, tempBuffer, 0, nominalMessageLength);
                              m_bufferStartPoint += nominalMessageLength;
                              
                              System.Diagnostics.Debug.Assert(m_bufferStartPoint < m_bufferCopyPoint);
                              resultList.Add(tempBuffer);

                              byte id = tempBuffer[4];
                              m_logger.Info(string.Format("[ {0} ] Message located. ID={1:x}, Length={2:x}", m_messageCounter, id, nominalMessageLength));
                              m_messageCounter++;

                              // enqueue to gmti
                              m_seekState = SeekState.Searching;
                              m_logger.Debug(string.Format("SeekState={0}", m_seekState));

                           }
                           else
                           {
                              loopBreakFlag = true; // more data needed in inputBuffer
                           }
                        }
                        else // not a message nor a preamble at 'segmentStartPoint'
                        {
                           m_seekState = SeekState.Searching;
                           m_logger.Debug(string.Format("SeekState={0}", m_seekState));
                        }
                  }
                  break;
            }

         } while (loopBreakFlag == false);

         return resultList;
      }

      /// <summary>
      /// Move data (unknown size) to InputBuffer
      /// </summary>
      private int MoveFromTcpToInputBuffer()
      {
         int numberOfReceivedBytes = 0;
         int freeSpaceInInputBuffer = 0;
#if method1
         numberOfReceivedBytes = m_localSocket.Receive(m_tcpInputBuffer);//, inputBufferCopyPointer, SocketFlags.None);
         Buffer.BlockCopy(m_tcpInputBuffer, 0, m_inputBuffer, m_bufferCopyPoint, numberOfReceivedBytes);
         
#else
         freeSpaceInInputBuffer =  (m_inputBuffer.Length - m_bufferCopyPoint) >> 1;
         numberOfReceivedBytes = m_localSocket.Receive(m_inputBuffer, m_bufferCopyPoint, freeSpaceInInputBuffer, SocketFlags.None);
#endif
         m_totalBytesReadFromTcp += numberOfReceivedBytes;
         m_bufferCopyPoint += numberOfReceivedBytes;
         System.Diagnostics.Debug.Assert((m_inputBuffer.Length - m_bufferCopyPoint) > 10000);

         return numberOfReceivedBytes;
      }

      /// ///////////////////////////////////////////////




      /// <summary>
      /// Search for start of message or start of preamble
      /// </summary>
      /// <param name="startOffset"></param>
      /// <param name="endOffsetPlus1"></param>
      /// <returns>
      /// return offset of segment.
      /// if offset==endOffsetPlus1, no segment found
      /// if offset==endOffsetPlus1-1, first byte of segment found
      /// if offset lt endOffsetPlus1-1, segment found
      /// </returns>
      int BufferBlindSeek(int startOffset, int endOffsetPlus1)
      {
         int rc = endOffsetPlus1;

         System.Diagnostics.Debug.Assert(endOffsetPlus1 > startOffset);

         // find 
         //for (int i = startOffset; i < endOffsetPlus1; i++)

         int i = startOffset;
         while (i < endOffsetPlus1)
         {

            if ((m_inputBuffer[i] == m_preambleSegmentStartBytes[0]) ||
                 (m_inputBuffer[i] == m_messageSegmentStartBytes[0]))
            {
               if (i < (endOffsetPlus1 - 1))
               {
                  i++;
                  if ((m_inputBuffer[i] == m_preambleSegmentStartBytes[1]) ||
                       (m_inputBuffer[i] == m_messageSegmentStartBytes[1]))
                  {
                     rc = i-1;
                     break;
                  }
               }
               else // 
               {
                  System.Diagnostics.Debug.Assert(false, "first-segment-byte found in last byte of buffer");
                  rc = i;
                  break;
               }
            }
            i++;
         }

         int d = rc - startOffset;
         if ((d!=0) && (d!=4))
            m_logger.Warn(string.Format("BlindSeek: Seek length = {0} bytes", d));
         return rc;
      }
#if dont
      private void MessageLoop()
      {
         byte[] tcpInputBuffer = new byte[64000];
         byte[] inputBuffer = new byte[64000];
         byte[] targetBuffer = new byte[64000];
         int copyPointer = 0;
         int ac13Pointer = -1;
         int numberOfReceivedBytes = 0;
         int messageNominalLength = 0;
         byte[] searchPattern = new byte[] { 0xac, 0x13 };
         bool incompleteMessage_flag = false;

         while (true)
         {
            // get message from socket and copy it to inputBuffer
            numberOfReceivedBytes = m_localSocket.Receive(tcpInputBuffer);//, inputBufferCopyPointer, SocketFlags.None);
            Buffer.BlockCopy(tcpInputBuffer, 0, inputBuffer, copyPointer, numberOfReceivedBytes);
            byte firstByte = tcpInputBuffer[0];

            if (incompleteMessage_flag)
            {

               copyPointer += numberOfReceivedBytes;
               if (copyPointer > (ac13Pointer + messageNominalLength))
               {
                  incompleteMessage_flag = false;
                  Buffer.BlockCopy(inputBuffer, ac13Pointer, targetBuffer, 0, messageNominalLength);

                  // make shift in inputBuffer
                  int mep1Pointer = ac13Pointer + messageNominalLength;
                  int byteCount = copyPointer - mep1Pointer;
                  Buffer.BlockCopy(inputBuffer, mep1Pointer, inputBuffer, 0, byteCount);
                  copyPointer -= mep1Pointer;
               }
            }
            else
            {
               copyPointer += numberOfReceivedBytes;
               ac13Pointer = BufferSeek(inputBuffer, searchPattern, 0, copyPointer);
               if (ac13Pointer >= 0)
               {
                  messageNominalLength = BitConverter.ToInt16(inputBuffer, ac13Pointer + 2);
                  // if the whole message in contained in input buffer
                  if (copyPointer > (ac13Pointer + messageNominalLength))
                  {
                     incompleteMessage_flag = false;
                     Buffer.BlockCopy(inputBuffer, ac13Pointer, targetBuffer, 0, messageNominalLength);

                     // make shift in inputBuffer
                     int mep1Pointer = ac13Pointer + messageNominalLength;
                     int byteCount = copyPointer - mep1Pointer;
                     Buffer.BlockCopy(inputBuffer, mep1Pointer, inputBuffer, 0, byteCount);
                     copyPointer -= mep1Pointer;
                  }
                  else // need to read more from tcp
                  {
                     incompleteMessage_flag = true;
                  }
               }
               else // ac13 not found. decrement copyPointer. 
               {
                  copyPointer -= numberOfReceivedBytes;
                  continue;
               }
            }
         }

      }

      int BufferSeek(byte[] buffer, byte[] searchPattern, int startOffset, int endOffset)
      {
         int rc = -1;

         // check init conditions
         if (searchPattern.Length != 2)
            throw new ArgumentException("(searchPattern.Length != 2)");
         if (buffer.Length <= endOffset)
            throw new ArgumentException("");

         // find 
         for (int i = startOffset; i < (endOffset + 1); i++)
            if (buffer[i] == searchPattern[0])
               if (buffer[i + 1] == searchPattern[1])
               {
                  rc = i;
                  break;
               }

         return rc;
      }
#endif

   }
}
