using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace SocketClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Socket sock;
        private void button1_Click(object sender, EventArgs e)
        {
           IPAddress ipAdd = IPAddress.Parse("128.139.81.72");//128.139.81.72"); //"
            IPEndPoint ep = new IPEndPoint(ipAdd, 8000);
            sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            sock.Connect(ep);

            button1.Enabled = false;
            button2.Enabled = true;
        }

        Char a;
        private void button2_Click(object sender, EventArgs e)
        {
            byte[] msg = Encoding.UTF8.GetBytes(textBox1.Text);
            
                sock.Send(msg);

                byte[] buf = new byte[256];
                sock.Receive(buf);    
                string reply = Encoding.UTF8.GetString(buf);
                textBox2.Text = reply;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            sock.Shutdown(SocketShutdown.Both);
        }
    }
}