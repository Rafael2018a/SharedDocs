using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace UdpClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender1, EventArgs e)
        {

            byte[] data = new byte[1024];
            string input, stringData;

            IPEndPoint remoteEp = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            //string p = serverSocket.ProtocolType.ToString();
            //string t = serverSocket.SocketType.ToString();
            string message = "Hello, are you there?";
            data = Encoding.ASCII.GetBytes(message);
            for (int i = 0; i < 20; i++)
            {
               serverSocket.SendTo(data, data.Length, SocketFlags.None, remoteEp);
               System.Threading.Thread.Sleep(1000);
            }

            serverSocket.Close();

            //EndPoint RemoteEp = (EndPoint)(new IPEndPoint(IPAddress.Any, 0));
            //data = new byte[1024];
            //int recv=0;
            //if (serverSocket.Connected)
            //    recv = serverSocket.ReceiveFrom(data, ref RemoteEp);
            //listBox1.Items.Add( string.Format("Message received from {0}:", RemoteEp.ToString()));
            //listBox1.Items.Add( Encoding.ASCII.GetString(data, 0, recv));
 
        }
    }
}