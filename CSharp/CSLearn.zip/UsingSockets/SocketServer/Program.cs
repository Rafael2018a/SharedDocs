using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Xml;

namespace SocketServer
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         //p.TcpServer();
         p.UdpServer();
         Console.ReadKey();


      }

      void UdpServer()
      {
         int numberOfReceivedBytes;
         byte[] data = new byte[1024 * 100];

#if anyIp
            //IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 8000);
#else // uniq local ip
         //string hostName = Dns.GetHostName();
         //IPHostEntry localHostEntry = Dns.GetHostEntry(hostName);
         //int c = localHostEntry.AddressList.Length;

         IPAddress localIpAddress = IPAddress.Parse("127.0.0.1");  //localHost.AddressList[0];
         IPEndPoint localEp = new IPEndPoint(localIpAddress, 8000);
         //SocketAddress sa = localEp.Serialize();

#endif
         Socket sock1 = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
         sock1.Bind(localEp); // must call this before ReceiveFrom()
         Console.WriteLine("Waiting for a client Port=8000) ...");

         EndPoint remoteEp = (EndPoint)(new IPEndPoint(IPAddress.Any, 0)); // IPAddress.Any=0.0.0.0
         sock1.Blocking = false;
         while (true)
         {

         numberOfReceivedBytes = sock1.ReceiveFrom(data, ref remoteEp);

            string message = Encoding.ASCII.GetString(data, 0, numberOfReceivedBytes);
            Console.WriteLine("Message {0}\n===received from {1}:", message, remoteEp.ToString());
         }

         //System.IO.FileStream fs = new System.IO.FileStream("message.xml", System.IO.FileMode.Create, System.IO.FileAccess.Write);
         //System.IO.StreamWriter sw = new System.IO.StreamWriter(fs);
         //sw.WriteLine(message);
         //sw.Close();
         //fs.Close();

         //XmlDocument xDoc = new XmlDocument();

         //xDoc.LoadXml(message);
         //XmlNodeList xList = xDoc.ChildNodes;
         //foreach (XmlNode xn1 in xList)
         //{
         //   Console.WriteLine(xn1.InnerXml);
         //}
         //XmlWriter xWriter = XmlWriter.Create("message.xml");
         //xDoc.WriteTo( xWriter);
         //xWriter.Close();
         //Console.WriteLine();

         Console.ReadKey();
         // send reply
         //string welcome = "Welcome to my test server";
         //data = Encoding.ASCII.GetBytes(welcome);
         //sock1.SendTo(data, data.Length, SocketFlags.None, remoteEp);
      }

      void TcpServer()
      {
         string hostName = Dns.GetHostName();
         IPHostEntry localHost = Dns.GetHostEntry(hostName);
         //IPHostEntry localHost = Dns.GetHostByName( hostName);
         int c = localHost.AddressList.Length;
         //IPAddress localIpAddress = localHost.AddressList[0];
         IPAddress localIpAddress = IPAddress.Parse("127.0.0.1");
         IPEndPoint localEp = new IPEndPoint(localIpAddress, 8000);

         Socket localSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
         localSocket.Bind(localEp);

         localSocket.Listen(5);

         Console.WriteLine("TCP server is listening on IP {0}, Port {1}", localEp.Address.ToString(), localEp.Port.ToString());

         Socket remoteSocket;
         remoteSocket = localSocket.Accept();

         Console.WriteLine("Socket accepted. Local: {0} Remote: {1}", remoteSocket.LocalEndPoint.ToString(), remoteSocket.RemoteEndPoint.ToString());

         string receivedMessage;
         //int i = 0;
         do
         {
            byte[] buf = new byte[2048];
            try
            {
               int count = remoteSocket.Receive(buf);
               if (count == 0)
               {
                  Console.WriteLine("Remote server shutdown");
                  break;
               }
               receivedMessage = Encoding.UTF8.GetString(buf, 0, count);
               Console.WriteLine("Received Message:{0}", receivedMessage);
            }
            catch (Exception ex)
            {
               Console.WriteLine(ex.ToString());
               goto exit;
            }
            if (receivedMessage == "bye")
               break;

            //            byte[] reply = Encoding.UTF8.GetBytes(string.Format("OK {0}", i++));
            //            inSocket.Send(reply);

         } while (true);

         //         byte[] reply1 = Encoding.UTF8.GetBytes("goodbye");
         //         inSocket.Send(reply1);
         //reply1 = Encoding.UTF8.GetBytes("goodbye2");
         //theclientSocket.Send(reply1);
         

         //remoteSocket.Shutdown(SocketShutdown.Both);
         remoteSocket.Close();
         Console.WriteLine("Tcp server ending. remoteSocket.Connected={0}", remoteSocket.Connected);
         //theserver.Shutdown(SocketShutdown.Both);
         localSocket.Close();

      exit: return;
      }
   }
}
