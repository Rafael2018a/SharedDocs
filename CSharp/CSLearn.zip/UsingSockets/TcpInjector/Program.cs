﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace TcpInjector
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run();
      }

      IPEndPoint m_remoteEp;
      string m_inputFilename;

      private void Run()
      {
         //bool asServer = true;
         IPEndPoint remoteEp = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 5001);
         Socket aSocket = TcpConnect( remoteEp);
         FileInfo fi = new FileInfo(@"d:\_Home\GeneratorModel.uml");
         if (fi.Exists)
            SendFile(fi, aSocket);
         else
            Console.WriteLine("File does not exist");
         Console.ReadKey();


      }

      private void SendFile(FileInfo fi, Socket aSocket)
      {
         using (FileStream fs = fi.Open(FileMode.Open))
         {
            byte [] v = new byte[10];
            int len;
            do
            {
               len = fs.Read( v, 0, 10);
               aSocket.Send( v);
            } while (len>0);
         }
        
      }

      private Socket TcpConnect(IPEndPoint remoteEp)
      {
         Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
         s.Connect(remoteEp);
         return s;
      }
   }
}
