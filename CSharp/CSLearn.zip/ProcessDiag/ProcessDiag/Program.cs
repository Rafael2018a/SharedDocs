﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace ProcessDiag
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run();

         Console.ReadLine();
      }

      private void Run()
      {
         Process p = Process.GetCurrentProcess();
         p = Process.GetProcessById(3700);
         ProcessThreadCollection ptc = p.Threads;
         foreach (ProcessThread pt in ptc)
         {
            if (pt.ThreadState == ThreadState.Wait)
               Console.WriteLine("ID={0} WaitReason={1}", pt.Id, pt.WaitReason);
            else
               Console.WriteLine("ID={0} State={1}", pt.Id, pt.ThreadState);

            
           
         }
         
      }


   }
}
