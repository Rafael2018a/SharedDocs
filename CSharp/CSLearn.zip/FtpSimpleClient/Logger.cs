using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using log4net;

namespace FtpSimpleClient
{
   public class Logger
   {
      private Logger()
      {
         log4net.Config.XmlConfigurator.Configure();
         _log4netLogger = LogManager.GetLogger("MXfrManager");

         //m_clientLogger = LogManager.GetLogger("ClientLogger"); // this is an activity logger according to client request

         //log4net.Appender.FileAppender appender = new log4net.Appender.FileAppender();
         //log4net.Layout.PatternLayout layout = new log4net.Layout.PatternLayout("[%date] %message %newline");

         //appender.File = "clinetlogfile.log.txt";
         //appender.AppendToFile=true;

         //appender.Layout = layout;
         //appender.ActivateOptions();
         //log4net.Config.BasicConfigurator.Configure(appender);

      }
      private static object lockObject = new object();
      private readonly ILog _log4netLogger;// = LogManager.GetLogger( "MXfrManager" );
      //private readonly ILog m_clientLogger;// = LogManager.GetLogger( "MXfrManager" );
      private static Logger _instance;
      public static Logger Instance
      {
         get
         {
            lock (lockObject)
            {
               if (_instance == null)
                  _instance = new Logger();
            }
            return _instance;
         }
      }

      
      /// <summary>
      /// Write log line.
      /// </summary>
      /// <param name="ex"></param>
      /// <param name="level"></param>
      /// <param name="formatString"></param>
      /// <param name="args"></param>
      private void WriteLogLine(Exception ex, int level, string formatString, params object[] args)
      {
         if (formatString == null)
            formatString = "";

         StackFrame callerFrame = new StackFrame(2, true);
         DateTime dt = DateTime.Now;

         string userMessage = string.Format(formatString, args);
         // remove new-line from string (this is for EltaLog)
         userMessage = userMessage.Replace('\n', '-');
         userMessage = userMessage.Replace('\r', '-');

         string objectType = callerFrame.GetMethod().ReflectedType.Name;
         string enhancedMessage;
         if (ex == null)
         {
            enhancedMessage = string.Format("({0}.{1}, Line#{2}) {3}", objectType, callerFrame.GetMethod().Name, callerFrame.GetFileLineNumber(), userMessage);
         }
         else
         {
            string sysMessage = ex.ToString();
            // remove new-line from string (this is for EltaLog)
            sysMessage = sysMessage.Replace('\n', '-');
            sysMessage = sysMessage.Replace('\r', '-');
            enhancedMessage = string.Format("{0} {1}", userMessage, sysMessage);
         }

         _log4netLogger.Info(string.Format("|{0}|{1}|{2}|{3}|{4}|", level, dt.ToShortDateString(), dt.ToShortTimeString(), enhancedMessage, objectType));
      }


      public void Error(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(null, 0, formatString, args);
         }
      }

      public void Error(Exception ex, string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(ex, 0, formatString, args);
         }
      }

      public void Error(Exception ex)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(ex, 0, null);
         }
      }

      public void Warn(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(null, 1, formatString, args);
         }
      }
      //public static void  Warn(string formatString, params object[] args)
      //{
      //   lock (Instance._log4netLogger)
      //   {
      //      Instance.WriteLogLine(null, 1, formatString, args);
      //   }
      //}

      public void Info(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(null, 2, formatString, args);
         }
      }

      public void Debug(string formatString, params object[] args)
      {
         lock (_log4netLogger)
         {
            WriteLogLine(null, 3, formatString, args);
         }
      }


      public void WriteClientLogEntry(LogEntry entry)
      {
         // get details
         DateTime dt = DateTime.Now;

         string logFilename = BuildLogFilename(dt);
         

         string LogDirname = @".\..\LogFiles";
         DirectoryInfo di = new DirectoryInfo(LogDirname);
         if (!di.Exists)
            di.Create();

         FileInfo fi = new FileInfo(di.FullName + @"\" + logFilename);

         //if (!Directory.Exists(fi.DirectoryName))
         //{
         //   Logger.Instance.Error("Directory {0} does not exists. Line NOT added to sip file", fi.DirectoryName);
         //   rc = false;
         //   goto exit;
         //}

         FileStream fStream;
         try
         {
            fStream = fi.Open(FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
         }
         catch (Exception ex)
         {
            Logger.Instance.Warn("Could not open client log file {0} for writing; {1}", fi.FullName, ex.Message);
            goto exit;
         }
         // goto end of file
         fStream.Seek(0, SeekOrigin.End);
         StreamWriter sWriter = new StreamWriter(fStream);

         string WorkLogLine = String.Format("[{0}, User:{1}] {2}. {3}", dt.ToString("yyyy-MM-dd HH:mm:ss"), System.Environment.UserName, entry.EntryType.ToString(), entry.Message);
         sWriter.WriteLine(WorkLogLine);

         sWriter.Close();
         fStream.Close();

         exit: return;
      }

      private string BuildLogFilename(DateTime dt)
      {
         //string fullFileName = null;

         string dateString = dt.ToString("MMMyyyy");

         string fileName = "Log_" + dateString + ".txt";

         return fileName;
      }

   }

   public class LogEntry
   {
      LogEntryType m_logType;

      public LogEntryType EntryType
      {
         get { return m_logType; }
      }

      string m_message;
      public string Message { get { return m_message; } }

      int m_intValue;
      public int MissionId { get { return m_intValue; } }

      long m_longValue;
      public long MbytesPerSecond { get { return m_longValue; } }

      //DateTime m_timestamp;

      //public DateTime Timestamp
      //{
      //   get { return m_timestamp; }
      //}

      public LogEntry(string _message, int _missionId, long _mBytesPerSec, LogEntryType _logType)
      {
         m_message = _message;
         m_intValue = _missionId;
         m_longValue = _mBytesPerSec;
         //         m_timestamp = timestamp;
         m_logType = _logType;
      }
   }

   public enum LogEntryType
   {
      File_Transferred,
      File_Transferred_Manually,
      File_Deleted_On_Remote,
      File_Deleted_On_Local,
      Connection_Established,
      Program_Started,
      File_Parsing_Error
   };
}
