namespace FtpSimpleClient
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.button_download = new System.Windows.Forms.Button();
         this.textBox1 = new System.Windows.Forms.TextBox();
         this.button_connect = new System.Windows.Forms.Button();
         this.label1 = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.button_downloadNative = new System.Windows.Forms.Button();
         this.button_connectNative = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // button_download
         // 
         this.button_download.Enabled = false;
         this.button_download.Location = new System.Drawing.Point(13, 119);
         this.button_download.Name = "button_download";
         this.button_download.Size = new System.Drawing.Size(75, 23);
         this.button_download.TabIndex = 0;
         this.button_download.Text = "Download";
         this.button_download.UseVisualStyleBackColor = true;
         this.button_download.Click += new System.EventHandler(this.button_download_Click);
         // 
         // textBox1
         // 
         this.textBox1.Location = new System.Drawing.Point(13, 93);
         this.textBox1.Name = "textBox1";
         this.textBox1.Size = new System.Drawing.Size(181, 20);
         this.textBox1.TabIndex = 1;
         this.textBox1.Text = "file.dat";
         // 
         // button_connect
         // 
         this.button_connect.Location = new System.Drawing.Point(13, 13);
         this.button_connect.Name = "button_connect";
         this.button_connect.Size = new System.Drawing.Size(75, 23);
         this.button_connect.TabIndex = 2;
         this.button_connect.Text = "Connect";
         this.button_connect.UseVisualStyleBackColor = true;
         this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(13, 173);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(35, 13);
         this.label1.TabIndex = 3;
         this.label1.Text = "label1";
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(13, 200);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(35, 13);
         this.label2.TabIndex = 4;
         this.label2.Text = "label2";
         // 
         // button_downloadNative
         // 
         this.button_downloadNative.Enabled = false;
         this.button_downloadNative.Location = new System.Drawing.Point(240, 119);
         this.button_downloadNative.Name = "button_downloadNative";
         this.button_downloadNative.Size = new System.Drawing.Size(152, 23);
         this.button_downloadNative.TabIndex = 5;
         this.button_downloadNative.Text = "Download with native lib";
         this.button_downloadNative.UseVisualStyleBackColor = true;
         this.button_downloadNative.Click += new System.EventHandler(this.button_downloadNative_Click);
         // 
         // button_connectNative
         // 
         this.button_connectNative.Location = new System.Drawing.Point(240, 13);
         this.button_connectNative.Name = "button_connectNative";
         this.button_connectNative.Size = new System.Drawing.Size(152, 23);
         this.button_connectNative.TabIndex = 6;
         this.button_connectNative.Text = "Connect native";
         this.button_connectNative.UseVisualStyleBackColor = true;
         this.button_connectNative.Click += new System.EventHandler(this.button_connectNative_Click);
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(527, 273);
         this.Controls.Add(this.button_connectNative);
         this.Controls.Add(this.button_downloadNative);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.button_connect);
         this.Controls.Add(this.textBox1);
         this.Controls.Add(this.button_download);
         this.Name = "Form1";
         this.Text = "Form1";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button button_download;
      private System.Windows.Forms.TextBox textBox1;
      private System.Windows.Forms.Button button_connect;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button button_downloadNative;
      private System.Windows.Forms.Button button_connectNative;
   }
}

