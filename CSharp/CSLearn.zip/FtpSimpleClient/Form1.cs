using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.FtpAgent;

namespace FtpSimpleClient
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button_download_Click(object sender, EventArgs e)
      {
         button_download.Enabled = false;

         DateTime dtBefore = DateTime.Now;
         ConnectionsAgent.Instance.FtpClientLib.Get(@"D:\_Image\" + textBox1.Text, textBox1.Text);
         DateTime dtAfter = DateTime.Now;
         long ticks = (dtAfter.Ticks - dtBefore.Ticks)/10000;
         System.IO.FileInfo fi = new System.IO.FileInfo(@"D:\_Image\" + textBox1.Text);
         long filesize = fi.Length;

         label1.Text = string.Format("Result: Download time {0} uS, File size {1} byte", ticks, filesize);
         label2.Text = string.Format("{0:##,###} MBytes/Sec (Mega=1,000,000)", filesize / ticks);

         button_download.Enabled = true;
      }

      private void button_connect_Click(object sender, EventArgs e)
      {
         ConnectionsAgent.Instance.ConnectFtp();
         button_download.Enabled = true;
         button_connect.Enabled = false;
      }

      FtpAgent agent;
      private void button_connectNative_Click(object sender, EventArgs e)
      {
         agent = new FtpAgent("localhost", "ftp", "aaa@bbb.com");
         button_downloadNative.Enabled = true;
         button_connectNative.Enabled = false;
      }

      private void button_downloadNative_Click(object sender, EventArgs e)
      {
         button_downloadNative.Enabled = false;

         DateTime dtBefore = DateTime.Now;
         agent.FileDownload(textBox1.Text, @"D:\_Image\", true);
         DateTime dtAfter = DateTime.Now;
         long ticks = (dtAfter.Ticks - dtBefore.Ticks) / 10000;
         System.IO.FileInfo fi = new System.IO.FileInfo(@"D:\_Image\" + textBox1.Text);
         long filesize = fi.Length;

         label1.Text = string.Format("Result: Download time {0} uS, File size {1} byte", ticks, filesize);
         label2.Text = string.Format("{0:##,###} MBytes/Sec (Mega=1,000,000)", filesize / ticks);

         button_downloadNative.Enabled = true;




      }

   }
}