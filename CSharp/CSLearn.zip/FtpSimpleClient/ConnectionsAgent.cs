using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using EnterpriseDT.Net.Ftp;


namespace FtpSimpleClient
{

   /// <summary>
   /// Responsible for ftp and tcp (remoting) connections
   /// </summary>
   class ConnectionsAgent
   {
      private static object lockObject = new object();
      private static ConnectionsAgent _instance;
      public static ConnectionsAgent Instance
      {
         get
         {
            lock ( lockObject )
            {
               if ( _instance == null )
                  _instance = new ConnectionsAgent();
            }
            return _instance;
         }
      }

      

      private FTPClient _ftpClient = new FTPClient();
      public FTPClient FtpClientLib
      { get { return _ftpClient; } }

      private bool m_requestToStopAllConnectionAttempts_flag = false;
      public bool StopAllConnectionAttemptsFlag
      { set { m_requestToStopAllConnectionAttempts_flag = value; } }
      //private bool m_ftpConnected = false;
      //public bool FtpConnected
      //{
      //   get { return m_ftpConnected; }
      //   set { m_ftpConnected = value; }
      //}
      

      public void DisconnectFtp()
      {
            try
            {
               _ftpClient.Quit();
            }
            catch (/*EnterpriseDT.Net.Ftp.FTP*/Exception ex)
            {
               //if (!ex.Message.StartsWith("The FTP client has not yet connected to the server"))
               //   throw;
               Logger.Instance.Warn("{0} {1}", ex.GetType(), ex.Message);
            }
         //m_ftpConnected=false;
      }
      /// <summary>
      /// Try to connect ftp and tcp (remoting). Throw 
      /// </summary>
      public bool ConnectFtp()
      {
         bool retVal = false;
         

         // if ftp connected then quit (not sure about this flag, so disconnect and then conncet again)
         //if (m_ftpConnected)
         {
            DisconnectFtp();
         }
         while (m_requestToStopAllConnectionAttempts_flag == false) // loop until connection established
         {
            try
            {
               _ftpClient.RemoteHost = "localhost";
               _ftpClient.Connect();

               _ftpClient.Login("ftp", "aaa@bbb.com");

               _ftpClient.ConnectMode = FTPConnectMode.PASV;
               _ftpClient.TransferType = FTPTransferType.BINARY;

               //m_ftpConnected = true;
               retVal = true;

               break;
            }
            //catch (EnterpriseDT.Net.Ftp.FTPException ex)
            //{
            //   // automatically quit
            //   if (ex.Message.StartsWith("The FTP client has already been connected to the server"))
            //   {
            //      Logger.Instance.Error("{0}", ex.Message);
            //      _ftpClient.Quit();
            //   }
            //}
            catch (Exception ex)
            {
               Logger.Instance.Error(ex);
            }
            finally
            {
               System.Threading.Thread.Sleep(1000);
            }
         }
         return retVal;
      }
      //*********************************************************************************************************************

      // remote proxy

      //public bool AllConnectionsActive()
      //{
      //   bool rc=true;
      //   try
      //   {
      //      _ftpClient.Pwd();
      //      _proxy.RemoteLibrary.Ping();
      //   }
      //   catch ( Exception )
      //   { rc = false; }

      //   return rc;

      //}


   }
}
