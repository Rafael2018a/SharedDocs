using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;

namespace System.Net.FtpAgent
{

   /// <summary>
   /// FtpAgent is a simple ftp client. It is based on .Net framework 2.0 classes from System.IO namespace
   /// Its main advantage is simplicity. The user of this class doesn't have to deal with the internals of web programming,
   /// simply call FileDownload( "thefile.txt", "C:\\", true) and the file will be downloaded to C:\
   /// </summary>
   /// <example>
   /// FtpAgent agent = new FtpAgent( "scma137", "haim", "haim1" );
   ///  try { agent.FileDownload( "/Rafi/username.txt", new DirectoryInfo( @"D:\_Image\" ), true ); }
   ///  catch (FtpAgentException ex)
   ///  {MessageBox.Show( "Could not download file.\n" + ex.Message );}
   /// </example>
   class FtpAgent
   {
      public FtpAgent(string hostname)
      {
         m_hostName = hostname;
      }

      public FtpAgent(string hostName, string userName, string password)
      {
         m_hostName = hostName;
         m_credentials = new NetworkCredential(userName, password);
      }

      private string m_hostName;
      /// <summary>
      /// Ftp host name
      /// </summary>
      /// <example>ftp.elta.com</example>
      public string HostName
      {
         get { return m_hostName; }
         set { m_hostName = value; }
      }

      private NetworkCredential m_credentials = null; // As long as this field is null, credentials won't be used.
      /// <summary>
      /// Allows to enter username, password and domain name.
      /// </summary>
      public NetworkCredential Credentials
      {
         get { return m_credentials; }
         set { m_credentials = value; }
      }

      //private string m_username;

      //public string Username
      //{
      //   get { return m_username; }
      //   set { m_username = value; }
      //}
      //private string m_password;
      //public string Password
      //{
      //   get { return m_password; }
      //   set { m_password = value; }
      //}

      private string m_currentRemoteDir = "/";

      /// <summary>
      /// Remote dir on ftp storage. (Must start and end with "/". Default value of this field is the root dir "/").
      /// </summary>
      public string CurrentRemoteDir
      {
         get { return m_currentRemoteDir; }
         set { m_currentRemoteDir = value; }
      }
      /// <summary>
      /// Add '/' to start and end of m_currentRemoteDir. Use with caution!
      /// </summary>
      public string CurrentRemoteDirFixed
      {
         get
         {
            // prefix
            string prefixedDir = m_currentRemoteDir.StartsWith("/") ? m_currentRemoteDir : "/" + m_currentRemoteDir;
            // postfix
            string fixedDir = prefixedDir.EndsWith("/") ? prefixedDir : prefixedDir + "/";
            return fixedDir;
         }
      }

      //private string m_lastErrorMessage;
      /// <summary>
      /// Error message after a method from this class failed.
      /// </summary>
      //public string LastErrorMessage
      //{
      //   get { return m_lastErrorMessage; }
      //}

      public List<string> ListDirectory()
      {
         return ListDirectory("/");
      }

      //public bool CheckHostConnection()
      //{
      //   List<string> dummy;
      //   try { dummy = ListDirectory( "/" ); }
      //   catch ( Exception ex )
      //   {
      //      return false;
      //   }
      //   if ( dummy == null )
      //      return false;
      //   else
      //      return true;
      //}

      /// <summary>
      /// perform a simple directory listing (ls) on remote ftp host
      /// </summary>
      /// <param name="directory">Directory to list, e.g. /pub</param>
      /// <returns>A list of filenames and directories as a List(strings), null in case of error</returns>
      /// <remarks>For a detailed directory listing, use ListDirectoryDetail</remarks>
      public List<string> ListDirectory(string directory)
      {
         // check init conditions
         if (!IsLegalDir(directory))
            throw new FtpAgentException(string.Format("Directory string {0} in not legal.", directory));

         // Get request object
         string url = BuildUrl(directory);
         System.Net.FtpWebRequest ftpRequest = GetFtpRequest(url);

         // Do a simple list and get response stream
         FtpWebResponse ftpResponse = null;
         ftpRequest.Method = System.Net.WebRequestMethods.Ftp.ListDirectory;

         Stream responseStream = null;
         List<string> resultList = null;
         try
         {
            ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
            // fill result list from response stream
            responseStream = ftpResponse.GetResponseStream();
            StreamReader sr = new StreamReader(responseStream);
            resultList = new List<string>();
            string line;
            while (true)
            {
               line = sr.ReadLine();
               if (line == null)
                  break;//loop
               resultList.Add(line);
            }
         }
         catch (Exception ex)
         {
            throw new FtpAgentException(string.Format("ListDirectory failure. URI: {0}\n{1}", url, ex.Message), ex);
         }
         finally
         {
            if (ftpResponse != null)
               ftpResponse.Close();
            if (responseStream != null)
               responseStream.Close();
         }

         return resultList;
      }

      public void FileDownload(string remoteFilename, string locaDir, bool PermitOverwrite)
      {
         DirectoryInfo di = new DirectoryInfo(locaDir);
         this.FileDownload(remoteFilename, di, PermitOverwrite);
      }

      public void FileDownload(FtpFileInfo remoteFileInfo, DirectoryInfo localDirInfo, bool PermitOverwrite)
      {
         this.FileDownload(remoteFileInfo.FullName, localDirInfo, PermitOverwrite);
      }

      /// <summary>
      /// Download file from remote ftp host to local dir
      /// </summary>
      /// <param name="remoteFileName"></param>
      /// <param name="localDirInfo"></param>
      /// <param name="PermitOverwrite"></param>
      /// <returns>true on success, false on failure</returns>
      public void FileDownload(string remoteFileName, DirectoryInfo localDirInfo, bool PermitOverwrite)
      {
         FileInfo localFileInfo;

         // build local filename & fileinfo
         int i;
         if ((i = remoteFileName.LastIndexOf('/')) >= 0)
            localFileInfo = new FileInfo(localDirInfo.FullName + "\\" + remoteFileName.Substring(i + 1));
         else
            localFileInfo = new FileInfo(localDirInfo.FullName + "\\" + remoteFileName);

         // check init conditions
         if (localFileInfo.Exists && !(PermitOverwrite))
         {
            throw new FtpAgentException(string.Format("Target file {0} already exists", localDirInfo.FullName));
         }

         // build remote full filename & url
         string remoteFileFullName;
         if (remoteFileName.StartsWith("/"))
            remoteFileFullName = remoteFileName;
         else
            remoteFileFullName = CurrentRemoteDirFixed + remoteFileName;
         string url = BuildUrl(remoteFileFullName);

         // perform copy
         //-------------
         System.Net.FtpWebRequest ftpRequest = GetFtpRequest(url);

         //Set request to download a file in binary mode
         ftpRequest.Method = System.Net.WebRequestMethods.Ftp.DownloadFile;
         ftpRequest.UseBinary = true;

         //Open request and get response stream
         FtpWebResponse ftpResponse;
         ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();

         using (Stream responseStream = ftpResponse.GetResponseStream())
         {
            //loop to read & write to file
            using (FileStream fs = localFileInfo.Open(FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read))
            {
               byte[] buffer = new byte[64000];
               int NoOfBytesRead = 0;

               do
               {
                  NoOfBytesRead = responseStream.Read(buffer, 0, buffer.Length);
                  fs.Write(buffer, 0, NoOfBytesRead);
               } while (NoOfBytesRead > 0);
            }

            responseStream.Close();
            ftpResponse.Close();
         }

      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="localFileInfo"></param>
      /// <returns></returns>
      public void FileUpload(FileInfo localFileInfo)
      {
         FileUpload(localFileInfo, m_currentRemoteDir);
      }
      /// <summary>
      /// 
      /// </summary>
      /// <param name="localFileInfo"></param>
      /// <param name="remoteDir">remote dir to uplod. If name is not absolute path, name will be prefixed with default dir</param>
      /// <returns></returns>
      public void FileUpload(FileInfo localFileInfo, string remoteDir)
      {
         string fixedRemoteDir = FixFtpDir(remoteDir);

         // check local
         if (!localFileInfo.Exists)
            throw new FtpAgentException(string.Format("Can't upload. Local file {0} does not exist.", localFileInfo.FullName));

         // build ftp path
         string url = BuildUrl(fixedRemoteDir + localFileInfo.Name);

         // issue request to upload a file in binary
         System.Net.FtpWebRequest ftpRequest = GetFtpRequest(url);
         ftpRequest.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
         ftpRequest.UseBinary = true;
         ftpRequest.ContentLength = localFileInfo.Length;//Notify FTP of the expected size

         // vars for the upload process
         const int bufferSize = 2048;
         byte[] buffer = new byte[bufferSize];
         int NoOfBytesRead;
         FileStream sourceStream = null;
         Stream requestStream = null;
         // start the upload process
         try
         {
            // open streams
            sourceStream = localFileInfo.OpenRead();
            requestStream = ftpRequest.GetRequestStream();
            do
            {
               NoOfBytesRead = sourceStream.Read(buffer, 0, bufferSize);
               requestStream.Write(buffer, 0, NoOfBytesRead);
            } while (NoOfBytesRead >= bufferSize);
         }
         catch (Exception ex)
         {
            throw new FtpAgentException(string.Format("Problem in uploading file {0} to remote dir {1}.\n{2}", localFileInfo.Name, remoteDir, ex.Message), ex);
         }
         finally
         {
            if (requestStream != null)
               requestStream.Close();
            if (sourceStream != null)
               sourceStream.Close();
         }

      }


      /// <summary>
      /// Delete remote file from ftp storage.
      /// </summary>
      /// <param name="filename">File to delete. If name not include absolute path, default dir will be used</param>
      /// <returns></returns>
      public void FileDelete(string filename)
      {
         string remoteFileFullName = GetFullFtpFilename(filename);
         string url = BuildUrl(remoteFileFullName);

         //Set request to delete
         System.Net.FtpWebRequest ftpRequest = GetFtpRequest(url);
         ftpRequest.Method = System.Net.WebRequestMethods.Ftp.DeleteFile;

         //Open request and get response stream
         FtpWebResponse ftpResponse;
         try
         {
            ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
         }
         catch (WebException ex)
         {
            throw new FtpAgentException("Problem in deleting file " + url + ".\n" + ex.Message, ex);
         }

      }

      /// <summary>
      /// Return FtpWebRequest object for the specified url, and set properties to the returned object.
      /// </summary>
      /// <param name="URI"></param>
      /// <returns></returns>
      private FtpWebRequest GetFtpRequest(string URI)
      {
         //create request
         FtpWebRequest ftpRequest = (FtpWebRequest)FtpWebRequest.Create(URI);
         //Set the login details
         if (m_credentials != null)
            ftpRequest.Credentials = m_credentials;
         //Do not keep alive (stateless mode)
         ftpRequest.KeepAlive = false;

         return ftpRequest;
      }

      /// <summary>
      /// Build URL according to host name and directory or full file name
      /// </summary>
      /// <param name="target"></param>
      /// <returns></returns>
      private string BuildUrl(string target)
      {
         string url = "ftp://" + m_hostName + target;
         return url;
      }

      /// <summary>
      /// verify that remoteFtpDir dir starts and ends with "/"
      /// </summary>
      /// <param name="remoteFtpDir"></param>
      /// <returns></returns>
      private bool IsLegalDir(string remoteFtpDir)
      {
         if (!remoteFtpDir.StartsWith("/"))
            return false;
         if (!remoteFtpDir.EndsWith("/"))
            return false;

         return true;
      }

      /// <summary>
      /// Add trailing slash if necessary. Prefix relative dir with default dir.
      /// </summary>
      /// <param name="ftpDir"></param>
      /// <returns></returns>
      private string FixFtpDir(string ftpDir)
      {
         string fixedDir1 = null;
         string fixedDir2 = null;
         // prefix
         fixedDir1 = ftpDir.StartsWith("/") ? ftpDir : CurrentRemoteDirFixed + ftpDir;
         // postfix
         fixedDir2 = fixedDir1.EndsWith("/") ? fixedDir1 : fixedDir1 + "/";

         return fixedDir2;
      }


      private string GetFullFtpFilename(string ftpFile)
      {
         string fixedDir1 = null;
         fixedDir1 = ftpFile.StartsWith("/") ? ftpFile : CurrentRemoteDirFixed + ftpFile;
         return fixedDir1;
      }
   }


   /// <summary>
   /// Represents a file or directory entry from an FTP listing
   /// </summary>
   /// <remarks>
   /// This class is used to parse the results from a detailed
   /// directory list from FTP. It supports most formats of
   /// </remarks>
   public class FtpFileInfo
   {
      private string m_filename;
      private string m_path;
      private EntryType m_fileType;
      private long m_size;
      private DateTime m_fileDateTime;
      private string m_permission;
      private string m_rawLine;

      public string FullName
      {
         get { return Path + Filename; }
      }
      public string Filename
      {
         get { return m_filename; }
      }
      public string Path
      {
         get { return m_path; }
      }
      public EntryType FileType
      {
         get { return m_fileType; }
      }
      public long Size
      {
         get { return m_size; }
      }
      public DateTime FileDateTime
      {
         get { return m_fileDateTime; }
      }
      public string Permission
      {
         get { return m_permission; }
      }
      public string Extension
      {
         get
         {
            int i = this.Filename.LastIndexOf(".");
            if (i >= 0 && i < (this.Filename.Length - 1))
            {
               return this.Filename.Substring(i + 1);
            }
            else
            {
               return "";
            }
         }
      }
      public string NameOnly
      {
         get
         {
            int i = this.Filename.LastIndexOf(".");
            if (i > 0)
            {
               return this.Filename.Substring(0, i);
            }
            else
            {
               return this.Filename;
            }
         }
      }
      public string RawLine { get { return m_rawLine; } }

      // ***

      /// <summary>
      /// Identifies entry as either File or Directory
      /// </summary>
      public enum EntryType
      {
         File, Directory
      }

      /// <summary>
      /// Constructor taking a directory listing line and path
      /// </summary>
      /// <param name="line">The line returned from the detailed directory list</param>
      /// <param name="path">Path of the directory</param>
      /// <remarks></remarks>
      public FtpFileInfo(string line, string path)
      {
         //parse line
         Match m = GetMatchingRegex(line);
         if (m == null)
         {
            //failed
            throw (new ApplicationException("Unable to parse line: " + line));
         }
         else
         {
            m_rawLine = line;

            m_filename = m.Groups["name"].Value;
            m_path = path;

            Int64.TryParse(m.Groups["size"].Value, out m_size);
            //_size = System.Convert.ToInt32(m.Groups["size"].Value);

            m_permission = m.Groups["permission"].Value;
            string _dir = m.Groups["dir"].Value;
            if (_dir != "" && _dir != "-")
            {
               m_fileType = EntryType.Directory;
            }
            else
            {
               m_fileType = EntryType.File;
            }

            try
            {
               m_fileDateTime = DateTime.Parse(m.Groups["timestamp"].Value);
            }
            catch (Exception)
            {
               m_fileDateTime = Convert.ToDateTime(null);
            }

         }
      }

      private Match GetMatchingRegex(string line)
      {
         Regex rx;
         Match m;
         for (int i = 0; i <= _ParseFormats.Length - 1; i++)
         {
            rx = new Regex(_ParseFormats[i]);
            m = rx.Match(line);
            if (m.Success)
            {
               return m;
            }
         }
         return null;
      }

      // *** "Regular expressions for parsing LIST results"
      /// <summary>
      /// List of REGEX formats for different FTP server listing formats
      /// </summary>
      /// <remarks>
      /// The first three are various UNIX/LINUX formats, fourth is for MS FTP
      /// in detailed mode and the last for MS FTP in 'DOS' mode.
      /// I wish VB.NET had support for Const arrays like C# but there you go
      /// </remarks>
      private static string[] _ParseFormats = new string[] { 
            "(?<dir>[\\-d])(?<permission>([\\-r][\\-w][\\-xs]){3})\\s+\\d+\\s+\\w+\\s+\\w+\\s+(?<size>\\d+)\\s+(?<timestamp>\\w+\\s+\\d+\\s+\\d{4})\\s+(?<name>.+)", 
            "(?<dir>[\\-d])(?<permission>([\\-r][\\-w][\\-xs]){3})\\s+\\d+\\s+\\d+\\s+(?<size>\\d+)\\s+(?<timestamp>\\w+\\s+\\d+\\s+\\d{4})\\s+(?<name>.+)", 
            "(?<dir>[\\-d])(?<permission>([\\-r][\\-w][\\-xs]){3})\\s+\\d+\\s+\\d+\\s+(?<size>\\d+)\\s+(?<timestamp>\\w+\\s+\\d+\\s+\\d{1,2}:\\d{2})\\s+(?<name>.+)", 
            "(?<dir>[\\-d])(?<permission>([\\-r][\\-w][\\-xs]){3})\\s+\\d+\\s+\\w+\\s+\\w+\\s+(?<size>\\d+)\\s+(?<timestamp>\\w+\\s+\\d+\\s+\\d{1,2}:\\d{2})\\s+(?<name>.+)", 
            "(?<dir>[\\-d])(?<permission>([\\-r][\\-w][\\-xs]){3})(\\s+)(?<size>(\\d+))(\\s+)(?<ctbit>(\\w+\\s\\w+))(\\s+)(?<size2>(\\d+))\\s+(?<timestamp>\\w+\\s+\\d+\\s+\\d{2}:\\d{2})\\s+(?<name>.+)", 
            "(?<timestamp>\\d{2}\\-\\d{2}\\-\\d{2}\\s+\\d{2}:\\d{2}[Aa|Pp][mM])\\s+(?<dir>\\<\\w+\\>){0,1}(?<size>\\d+){0,1}\\s+(?<name>.+)" };
      // ***
   }

   class FtpAgentException: Exception
   {
      public FtpAgentException(string message, Exception innerException) : base(message, innerException) { }
      public FtpAgentException(string message) : base(message) { }
   }

}
