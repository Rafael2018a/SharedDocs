using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace RemotingLibraryClient
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }


      RemoteLibraryHost.MySponser m_sponser;
      //RemoteLibraryHost.
      //System.Runtime.Remoting.Channels.Tcp.TcpChannel m_channel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel();
      private void button1_Click(object sender, EventArgs e)
      {
         try
         {

            // register channael
            //------------------
            System.Runtime.Remoting.Channels.BinaryServerFormatterSinkProvider formatter = new System.Runtime.Remoting.Channels.BinaryServerFormatterSinkProvider();
            formatter.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;

            System.Collections.IDictionary channelProperties = new System.Collections.Hashtable();
            channelProperties["name"] = "FullHostTCPChannel";
            channelProperties["port"] = 13102;

            System.Runtime.Remoting.Channels.IChannel channel = new TcpChannel(channelProperties, null, formatter);

            //System.Runtime.Remoting.Channels.Tcp.TcpChannel channel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel(0);
            System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(channel, false);

            // define leasing params
            //LifetimeServices.LeaseTime = TimeSpan.FromSeconds(9);
            //ifetimeServices.RenewOnCallTime = TimeSpan.FromSeconds(9);
            //LifetimeServices.LeaseManagerPollTime = TimeSpan.FromSeconds(1);

            RemotingConfiguration.RegisterWellKnownClientType(typeof(RemoteLibrary.RemoteClass), "tcp://localhost:13101/myurl.soap");

            // get remote object
            RemoteLibrary.RemoteClass m_remoteObject = new RemoteLibrary.RemoteClass();
            System.Diagnostics.Debug.Assert(RemotingServices.IsObjectOutOfAppDomain(m_remoteObject) == true);

            ILease leaseObject = (ILease)RemotingServices.GetLifetimeService(m_remoteObject);
            m_sponser = new RemoteLibraryHost.MySponser();
            leaseObject.Register(m_sponser);
            TimeSpan ts = leaseObject.CurrentLeaseTime;
            LeaseState ls =  leaseObject.CurrentState;

            m_remoteObject.DoSomthing();

            // activate remote event
            RemoteLibrary.RemoteCallbackWrapper rcw = new RemoteLibrary.RemoteCallbackWrapper();
            //m_remoteObject.remoteLibEvent+=new RemoteLibrary.RemoteClass.remoteLibEventHandler(rcw.m_remoteObject_remoteLibEvent_DM);
            m_remoteObject.remoteLibEvent += LocalCallback;
            m_remoteObject.ActivateEvent();
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.ToString());
            throw;
         }

      }

      public void LocalCallback()
      {
         MessageBox.Show("LocalCallback called");
      }

   }
}