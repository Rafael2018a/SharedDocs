using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting.Channels.Tcp;

namespace RemoteLibraryHost
{
   class Program
   {
      static System.Timers.Timer timer1 = new System.Timers.Timer();
      static void Main(string[] args)
      {
         timer1.Interval = 1000;
         timer1.Elapsed += new System.Timers.ElapsedEventHandler(timer1_Elapsed);
         timer1.Enabled = true;
         // simple channel
         //System.Runtime.Remoting.Channels.Tcp.TcpChannel channel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel(13101);
         
         //===============================================================================

         LifetimeServices.LeaseTime = TimeSpan.FromSeconds(9);
         LifetimeServices.RenewOnCallTime = TimeSpan.FromSeconds(9);
         //LifetimeServices.LeaseManagerPollTime = TimeSpan.FromSeconds(1);



         System.Runtime.Remoting.Channels.BinaryServerFormatterSinkProvider formatter = new System.Runtime.Remoting.Channels.BinaryServerFormatterSinkProvider();
         formatter.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;

         System.Collections.IDictionary channelProperties = new System.Collections.Hashtable();
         channelProperties["name"] = "FullHostTCPChannel";
         channelProperties["port"] = 13101;

         System.Runtime.Remoting.Channels.IChannel channel = new TcpChannel(channelProperties, null, formatter);
            
         System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(channel, false);

         // register as wko/singleton
         RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteLibrary.RemoteClass), "myurl.soap", WellKnownObjectMode.Singleton );

         // register also as cao
         RemotingConfiguration.RegisterActivatedServiceType(typeof(RemoteLibrary.RemoteClass));

         Console.ReadKey();

         //System.Runtime.Remoting.Channels.ChannelServices.UnregisterChannel(channel);

      }

      static void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
      {
         GC.Collect();
      }


   }
}
