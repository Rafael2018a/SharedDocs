using System;
using System.Collections.Generic;
using System.Text;


namespace RemoteLibraryHost
{
   public class MySponser: MarshalByRefObject, System.Runtime.Remoting.Lifetime.ISponsor 
   {
      int m_numberOfCalls = 0;
      public int NumberOfCalls
      {
         get { return m_numberOfCalls; }
         set { m_numberOfCalls = value; }
      }
      public TimeSpan Renewal( System.Runtime.Remoting.Lifetime.ILease lease)
      {
         System.Diagnostics.Debug.Assert(lease.CurrentState == System.Runtime.Remoting.Lifetime.LeaseState.Active);

         m_numberOfCalls++;
         //Renew lease by 5 seconds

         //System.Windows.Forms.MessageBox.Show("Sponser called");
         System.IO.FileStream fs = new System.IO.FileStream("remoting2.log.txt", System.IO.FileMode.Create, System.IO.FileAccess.Write);
         fs.WriteByte(50);
         fs.Close();

         return TimeSpan.FromSeconds(5);

         
      }
   }
}
