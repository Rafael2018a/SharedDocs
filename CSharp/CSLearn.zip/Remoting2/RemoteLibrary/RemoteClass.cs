using System;
using System.Collections.Generic;
using System.Text;

namespace RemoteLibrary
{
   public class RemoteClass: MarshalByRefObject
   {
      Guid m_objectGuid;
      public RemoteClass()
      {
         m_objectGuid = Guid.NewGuid();

         DisplayDetails("RemoteClass is up ");
      }

      public delegate void remoteLibEventHandler();
      public event EventHandler libEvent;
      public event remoteLibEventHandler remoteLibEvent;
      public void DoSomthing()
      {
         DisplayDetails("RemoteClass.DoSomthing() called");
      }
      public void ActivateEvent()
      {
         if (remoteLibEvent != null)
            remoteLibEvent();
      }
      ~RemoteClass()
      {
         DisplayDetails("RemoteClass is down ");
      }

      void DisplayDetails(string message)
      {
         Console.WriteLine("{0} {1} : Object={2:N} Thread={3} ",
            message,
            DateTime.Now.ToShortTimeString(),
            m_objectGuid,
            System.Threading.Thread.CurrentThread.GetHashCode()
            );
      }

   }

   [Serializable]
   public class RemoteCallbackWrapper
   {
      public void m_remoteObject_remoteLibEvent_DM()
      {
         Console.WriteLine("Callback called from remote");
      }

   }

}
