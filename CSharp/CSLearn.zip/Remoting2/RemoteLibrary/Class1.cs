using System;
using System.Collections.Generic;
using System.Text;

namespace RemoteLibrary
{
   public class Class1
   {
   }
}
