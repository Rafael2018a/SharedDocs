﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace GCTester
{
   /// <summary>
   /// try to find out the managed heap size
   /// </summary>
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         
         p.Run();

         
      }
//#if dont
      void Run()
      {
         GC.RegisterForFullGCNotification(10, 10);
         System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(AuxThread));
         t.IsBackground = true;
         t.Start();

         Console.WriteLine("Current allocated bytes: {0}", GC.GetTotalMemory(false));
         int blockSize = 50000;
         byte [] testBlock = new byte[blockSize];
         int testBlockGen = GC.GetGeneration(testBlock);
         byte[] volatileBlock;
         int i = 0;
         System.Collections.ArrayList al = new System.Collections.ArrayList();
         for(int j=0; j<500; j++)
         {
            volatileBlock = new byte[blockSize];
            al.Add(volatileBlock);
            i++;
            System.Threading.Thread.Sleep(100);
            Console.WriteLine("Current allocated bytes: {0}", GC.GetTotalMemory(false));
            int newTestBlockGen = GC.GetGeneration(testBlock);
            if (newTestBlockGen != testBlockGen)
            {
               Console.WriteLine("Number of blocks: {0}. GC0={1}, GC1={2}, GC2={3}", i, GC.CollectionCount(0), GC.GetGeneration(1), GC.GetGeneration(2));
               testBlockGen = newTestBlockGen;
            }
         }
        
      }
      ReaderWriterLockSlim rwls = new ReaderWriterLockSlim();
      void f()
      {
         
      }

      public void AuxThread()
      {
         GC.WaitForFullGCApproach();
         Console.WriteLine("GC approaching");
         GC.WaitForFullGCComplete();
         Console.WriteLine("GC completed");
      }
//#endif
   }
}
