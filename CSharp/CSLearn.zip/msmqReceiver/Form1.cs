using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Messaging;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;

namespace msmqReceiver
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Button button1;
      private System.Messaging.MessageQueue messageQueue1;
      private System.Windows.Forms.ListBox listBox1;
      private MessageQueue messageQueue2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.button1 = new System.Windows.Forms.Button();
         this.messageQueue1 = new System.Messaging.MessageQueue();
         this.listBox1 = new System.Windows.Forms.ListBox();
         this.messageQueue2 = new System.Messaging.MessageQueue();
         this.SuspendLayout();
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(24, 8);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(120, 23);
         this.button1.TabIndex = 0;
         this.button1.Text = "Start receiving";
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // messageQueue1
         // 
         this.messageQueue1.Formatter = new System.Messaging.BinaryMessageFormatter(System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Full, System.Runtime.Serialization.Formatters.FormatterTypeStyle.TypesAlways);
         this.messageQueue1.MessageReadPropertyFilter.LookupId = true;
         this.messageQueue1.Path = "FormatName:DIRECT=OS:e10003791\\private$\\alpha";
         this.messageQueue1.SynchronizingObject = this;
         // 
         // listBox1
         // 
         this.listBox1.Location = new System.Drawing.Point(24, 40);
         this.listBox1.Name = "listBox1";
         this.listBox1.Size = new System.Drawing.Size(240, 212);
         this.listBox1.TabIndex = 1;
         // 
         // messageQueue2
         // 
         this.messageQueue2.MessageReadPropertyFilter.LookupId = true;
         this.messageQueue2.Path = "FormatName:DIRECT=OS:e10003791\\private$\\alpha";
         this.messageQueue2.SynchronizingObject = this;
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(292, 273);
         this.Controls.Add(this.listBox1);
         this.Controls.Add(this.button1);
         this.Name = "Form1";
         this.Text = "Form1";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void button1_Click(object sender, System.EventArgs e)
      {
         messageQueue1.ReceiveCompleted+=new ReceiveCompletedEventHandler(messageQueue1_ReceiveCompleted);
         messageQueue1.BeginReceive();
//         messageQueue1.PeekCompleted+=new PeekCompletedEventHandler(messageQueue1_PeekCompleted);
//         messageQueue1.BeginPeek();
         listBox1.Items.Clear();
         button1.Enabled = false;
      }

      int fileNameCounter=0;
      private void messageQueue1_ReceiveCompleted(object source, ReceiveCompletedEventArgs asyncResult )
      {
         // Connect to the queue.
         MessageQueue mq = (MessageQueue)source;

         // End the asynchronous receive operation.
         System.Messaging.Message msg = mq.EndReceive(asyncResult.AsyncResult);
         msg.Formatter = new BinaryMessageFormatter();//new Type[] {typeof(string)});
         //string s = (string)msg.Body;
         //listBox1.Items.Add(s);
         FileStream fs = new FileStream(string.Format("Message{0}.soap.xml", fileNameCounter++), FileMode.Create, FileAccess.Write);
         SoapFormatter formatter = new SoapFormatter();
         formatter.Serialize( fs, msg.Body);
         fs.Close();



         // Restart the asynchronous receive operation.
         mq.BeginReceive();

      }

      private void messageQueue1_PeekCompleted(object sender, PeekCompletedEventArgs e)
      {
         // Connect to the queue.
         MessageQueue mq = (MessageQueue)sender;

         // End the asynchronous receive operation.
         System.Messaging.Message msg = mq.EndPeek(e.AsyncResult);
         msg.Formatter = new XmlMessageFormatter(new Type[] {typeof(string)});
         string s = (string)msg.Body;
         listBox1.Items.Add(s);

         mq.ReceiveById(msg.Id);
         //mq
                
         // Restart the asynchronous receive operation.
         mq.BeginPeek();
         
      }

   }
}
