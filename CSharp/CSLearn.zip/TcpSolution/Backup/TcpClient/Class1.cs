using System;
using System.IO;
using System.Net.Sockets;

namespace TcpClient1
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Class1 c1 = new Class1();
			c1.RunClient();
		}

		private void RunClient()
		{
			TcpClient client = new TcpClient("localhost", 50000);
			NetworkStream ns = client.GetStream();
			StreamWriter sw = new StreamWriter(ns);
			sw.WriteLine("hello from client");
			sw.Flush();
			StreamReader sr = new StreamReader(ns);
			Console.WriteLine("Reply from server: {0}", sr.ReadLine());
			sw.Close();
			client.Close();
			

		}
	}
}
