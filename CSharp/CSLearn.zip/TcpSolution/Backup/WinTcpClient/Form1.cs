using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.IO;

namespace WinTcpClient
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         textBox2.Clear();
         try
         {
            sw.WriteLine(textBox1.Text);
            sw.Flush();
         }
         catch (IOException ioe)
         {
            MessageBox.Show(ioe.ToString());
            return;
         }

         StreamReader sr = new StreamReader(ns);
         textBox2.Text = sr.ReadLine();


      }

      TcpClient client;
      NetworkStream ns;
      StreamWriter sw;

      private void button2_Click(object sender, EventArgs e)
      {
         try
         {
            client = new TcpClient("localhost", 50000);
         }
         catch (SocketException se)
         {
            MessageBox.Show(se.ToString());
            return;
         }
         ns = client.GetStream();
         sw = new StreamWriter(ns);

      }

      protected override void OnClosing(CancelEventArgs e)
      {
         base.OnClosing(e);


         sw.Close();
         ns.Close();
         client.Close();

      }
   }
}