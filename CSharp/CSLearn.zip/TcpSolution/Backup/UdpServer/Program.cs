using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace UdpServer
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.RunServer();
      }

      private void RunServer()
      {
         byte [] inputBuffer;
         IPAddress inputNetInterfaceIP = IPAddress.Parse("128.139.81.72");
         IPEndPoint localEp = new IPEndPoint(inputNetInterfaceIP, 5000);

         IPAddress multicastIp = IPAddress.Parse("225.255.1.8");

         UdpClient aUdpClient = new UdpClient(localEp);
         aUdpClient.JoinMulticastGroup(multicastIp);
         Console.WriteLine("Waiting for client on port 5000 ...");
         IPEndPoint ipEpSender = new IPEndPoint(0, 0);
         
         while (true)
         {
            inputBuffer = aUdpClient.Receive( ref ipEpSender);
            string messageFromClient = Encoding.ASCII.GetString(inputBuffer);
            Console.WriteLine("Message from {0}: {1}", ipEpSender.ToString(), messageFromClient);
         }
      }
   }
}
