using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace WinUdpClient
{
   public partial class Form1: Form
   {
      UdpClient m_aUdpClient;

      public Form1()
      {
         InitializeComponent();
         // m_aUdpClient = new UdpClient("228.3.1.3", 310);
      }

      private void button1_Click(object sender, EventArgs e)
      {
         IPAddress destIp = IPAddress.Parse(textBox_targetIp.Text);
         int port = Int32.Parse(textBox_targetPort.Text);
         m_aUdpClient = new UdpClient(textBox_targetIp.Text, port);
         //m_aUdpClient = new UdpClient("228.3.1.3", 310);
         

         byte[] binMessageToSend = Encoding.ASCII.GetBytes(textBox_textToSend.Text);
         m_aUdpClient.Send(binMessageToSend, binMessageToSend.Length);

         m_aUdpClient.Close();
      }

      protected override void OnClosing(CancelEventArgs e)
      {
         base.OnClosing(e);
         
      }
   }
}