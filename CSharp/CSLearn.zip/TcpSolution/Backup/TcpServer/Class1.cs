using System;
using System.IO;
using System.Net.Sockets;
using System.Text;

namespace TcpServer
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Class1 c1 = new Class1();
			c1.RunServer();

		}

      private void RunServer()
      {
         Console.WriteLine("initializing server");
         TcpListener listener = new TcpListener(50000);
         listener.Start();
         Console.WriteLine("Tcp Listener started. Waiting for incoming connections");
         Socket theSocket = listener.AcceptSocket();
         Console.WriteLine("Connection established. (socket accepted). Waiting for messages");
         NetworkStream ns = new NetworkStream(theSocket);
         //StreamReader sr = new StreamReader(ns);
         BinaryReader br = new BinaryReader(ns);
         string line = null;
         do
         {
            byte[] buffer = new byte[1000];
            //line = sr.ReadLine();
            int n = 0;
            try
            {
               n = br.Read(buffer, 0, 1000);
            }
            catch (IOException ex)
            {
               Console.WriteLine(ex.ToString());
               break;
            }

            line = Encoding.UTF8.GetString( buffer, 0, n);

            Console.WriteLine("$ {0}", line);

            string answer = "Ready\r\n";
            byte[] a = System.Text.ASCIIEncoding.ASCII.GetBytes(answer);
            theSocket.Send(a); // send back
         } while (line != null);

         br.Close();
         ns.Close();
         theSocket.Shutdown(SocketShutdown.Both);
         theSocket.Close();
         listener.Stop();
         Console.WriteLine("Remote client is no longer connected. Closing.");
         Console.WriteLine("Click any key to close console");
         Console.ReadKey();
      }
	}
}
