﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.IO;

namespace XmlValidator
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         if (p.CreateSchemaAssociations())
         {
            string result;
            p.ValidateXml(@"S:\Rafi\Gondola\Mti output Files\Imtg_633295081874062500_10011007_2_7_0_A1_001.mti", out result);//, @"S:\Rafi\Mti Files\mtiSchema.xsd");
            p.ValidateXml(@"S:\Rafi\Gondola\DMZ Test Files\55 files\Imtg_128049437710021288_424_6_5_23_A1_001.aux", out result);
            Console.WriteLine(result);
         }
      }

      System.Collections.Hashtable m_schemaAssociations = new Hashtable();

      bool CreateSchemaAssociations()
      {
         bool rc = false;
         try
         {
            using (FileStream xsStream = File.OpenRead(@"S:\Rafi\Gondola\mtiSchema.xsd"))
            {
               XmlSchema xSchema = XmlSchema.Read(xsStream, null);
               XmlReaderSettings xSettings = new XmlReaderSettings();
               xSettings.ValidationType = ValidationType.Schema;
               xSettings.Schemas.Add(xSchema);
               m_schemaAssociations.Add("Batch", xSettings);
            }
            using (FileStream xsStream = File.OpenRead(@"S:\Rafi\Gondola\DMZ Test Files\From Haim 1\GIRAuxiliaryFile5.xsd"))
            {
               XmlSchema xSchema = XmlSchema.Read(xsStream, null);
               XmlReaderSettings xSettings = new XmlReaderSettings();
               xSettings.ValidationType = ValidationType.Schema;
               xSettings.Schemas.Add(xSchema);
               m_schemaAssociations.Add("ImageData", xSettings);
            }
            rc = true;
         }
         catch (Exception ex)
         {
            rc = false;

         }

         return rc;
      }


      bool ValidateXml(string xmlFullFilename, out string resultString)//, string schemaFullFilename)
      {
         bool rc = false;
         string docElement;
         resultString = null;

         // open the target file
         try
         {
            using (FileStream xStream = File.OpenRead(xmlFullFilename))
            {
               XmlDocument xDoc = new XmlDocument();
               xDoc.Load(xStream);
               docElement = xDoc.DocumentElement.Name;
            }
         }
         catch (Exception ex)
         {
            resultString = string.Format("Problem occurred when trying to open xml file for validation. {0}\n{1}", xmlFullFilename, ex.Message);
            goto exit;
         }

         using (FileStream xStream = File.OpenRead(xmlFullFilename))
         {
            XmlReaderSettings xSettings = (XmlReaderSettings)m_schemaAssociations[docElement];
            if (xSettings == null)
            {
               resultString = string.Format("No suitable schema found for file {0}. DocElement of file is '{1}'", xmlFullFilename, docElement);
               goto exit;
            }
            using (XmlReader xReader = XmlReader.Create(xStream, xSettings))
            {
               try
               {
                  while (xReader.Read())
                  { }
               }
               catch (XmlSchemaValidationException ex)
               {
                  resultString = string.Format("XML file validation fail. Filename: {0}\n{1}", xmlFullFilename, ex.Message);
                  goto exit;
               }

               rc = true;
            }
         }

      exit: return rc;

      }

   }
}
