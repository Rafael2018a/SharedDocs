using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;

namespace xpathDemo
{
   public partial class Form1 : Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void button1_Click( object sender, EventArgs e )
      {
         XmlDocument xDoc = new XmlDocument();
         XmlNode docElement;
         FileInfo fi = new FileInfo( "DownloadList.xml" );

         if ( fi.Exists )
         {
            using ( FileStream fs = fi.Open( FileMode.Open, FileAccess.Read ) )
            {
               xDoc.Load( fs );
               docElement = xDoc.DocumentElement;



               string xpathExp = null;// string.Format("", filename);
               XmlNode xNode = docElement.SelectSingleNode( xpathExp );
               if ( xNode == null )
                  return true;
               else
                  return false;
            }
         }
         return false;

      }
   }
}