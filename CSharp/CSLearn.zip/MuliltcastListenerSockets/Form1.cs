using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace MuliltcastListener
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void newToolStripMenuItem_Click(object sender, EventArgs e)
      {

      }

      private void button_start_Click(object sender, EventArgs e)
      {
         bool rc=InitSocket();
         if (rc==true)
            MessageLoop();
      }

      private bool InitSocket()
      {
         IPAddress mcastIp = IPAddress.Parse(textBox_multicastIp.Text);
         IPAddress localNicIp = IPAddress.Parse(textBox_nicIp.Text);
         int mcasrPortNumber = Int32.Parse(textBox_portNumber.Text);
         IPEndPoint localEP = new IPEndPoint(localNicIp, mcasrPortNumber);

         Socket mcastReceiveSsocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
         mcastReceiveSsocket.Bind(localEP);



         MulticastOption mcOption = new MulticastOption();

         return false;
      }

      private void MessageLoop()
      {
         throw new Exception("The method or operation is not implemented.");
      }

   }
}