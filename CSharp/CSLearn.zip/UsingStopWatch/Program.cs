﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace UsingStopWatch
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run();

         Console.ReadLine();
      }

      System.Timers.Timer m_timer = null;
      Stopwatch sw;

   
      private void Run()
      {
         m_timer = new System.Timers.Timer();
         m_timer.Elapsed += new System.Timers.ElapsedEventHandler(m_timer_Elapsed);
         m_timer.Interval = 1000;
         m_timer.AutoReset = true;
         //m_timer.Enabled = true;

         sw = new Stopwatch();
         sw.Start();
         //System.Threading.Thread.Sleep(20);
         for (int i = 0; i < 5; i++)
         {
            //sw.Reset();
            
            
            System.Threading.Thread.Sleep(200);
            //sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
         }
         
      }

      void m_timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
      {
         //sw.Start();
         sw.Stop(); // does not stop the timer itself. This is just for reading
         Console.WriteLine(sw.ElapsedMilliseconds);
         //sw.Reset();
         
         sw.Start();

      }
      void f()
      {
        
      }
   }
}
