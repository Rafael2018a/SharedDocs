﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win32PerformanceCounter
{
   class Program
   {
      static void Main(string[] args)
      {
         Win32PerformanceCounter.StopWatch sw = new StopWatch();
         sw.Reset();
         long v1 = sw.Peek();
         System.Threading.Thread.Sleep(1);
         long v2 = sw.Peek();
         Console.WriteLine(v2 - v1);
         Console.ReadLine();
      }
   }
}
