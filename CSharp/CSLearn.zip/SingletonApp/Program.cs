using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SingletonApp
{
   static class Program
   {
      static System.Threading.Mutex m_appMutex;

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.EnableVisualStyles();
         Application.SetCompatibleTextRenderingDefault(false);
         if (IsFirstInstance())
         {
            Application.Run(new Form1());
         }
      }

      static bool IsFirstInstance()
      {
         string assemblyName = System.Reflection.Assembly.GetEntryAssembly().FullName;
         m_appMutex = new System.Threading.Mutex(false, assemblyName);
         bool owned = m_appMutex.WaitOne(TimeSpan.Zero, false);
         return owned;
      }

   }
}