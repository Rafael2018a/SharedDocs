﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace threadRandevu
{
   class Program
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run1();
      }

      void Run1()
      {
         Point p = new Point(10,11);
         f(p);

         int g = GC.GetGeneration(p);
      }
      System.Collections.ArrayList al = new System.Collections.ArrayList();
      void f(Point p)
      {
         Object o = null;
         Program p1 = (Program)o;
      }

      void Run()
      {
         //ThreadPool.QueueUserWorkItem(new WaitCallback(TM));
         Thread t1 = new Thread(new ParameterizedThreadStart(TM));
         t1.Start( TimeSpan.FromMilliseconds(10000));

         Thread t2 = new Thread(new ParameterizedThreadStart(TM));
         t2.Start(TimeSpan.FromMilliseconds(20000));

      }

      void TM(object timeout)
      {
         StackFrame sf = new StackFrame();
         string name = sf.GetMethod().Name;

         TimeSpan ts = (TimeSpan)timeout;
         Thread.Sleep(ts);
         Console.WriteLine("Thread {0} waiting ...", ts.TotalMilliseconds);
         WaitJoin();
         Console.WriteLine("Thread {0} terminating ...", ts.TotalMilliseconds);
      }

      AutoResetEvent re1 = new AutoResetEvent(true);
      AutoResetEvent re2 = new AutoResetEvent(false);

      void WaitJoin()
      {
         bool isFirstThread = re1.WaitOne(0);
         if (isFirstThread)
            re2.WaitOne();
         else
            re2.Set();
      }
   }

   struct Point
   {
      public Point(int a, int b)
      {
         x = a; y = b;
         Console.Write("Point ctor");
      }
      public int x, y;
   }
}
