using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting;
using WKO_Server;

namespace CAO_Server
{
   class Program
   {
      static void Main(string[] args)
      {
         System.Runtime.Remoting.Channels.Http.HttpChannel channel = new System.Runtime.Remoting.Channels.Http.HttpChannel(13101);
         System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(channel, false);

         RemotingConfiguration.RegisterActivatedServiceType(typeof(RemoteClass));

         Console.ReadKey();
      }
   }

}
