﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppDomain1
{
   //[Serializable]
   class Program: MarshalByRefObject
   {
      static void Main(string[] args)
      {
         Program p = new Program();
         p.Run();
      }

      private void Run()
      {
         AppDomain domain2 = AppDomain.CreateDomain("domain2");
         
         string aName = System.Reflection.Assembly.GetExecutingAssembly().FullName;
         System.Reflection.Assembly asm = domain2.Load(aName);
         Type t = asm.GetType("AppDomain1.Program");
         //object o = Activator.CreateInstance( t);
         Program op = (Program)domain2.CreateInstanceAndUnwrap(aName, "AppDomain1.Program");
         op.ProgramMethod();
         //System.Reflection.MethodInfo mi = t.GetMethod("ProgramMethod");
         //mi.Invoke (o, null);

         for (int i = 0; i < 5; i++)
         {
            Console.WriteLine(string.Format("Domain1: {0} thread id {1}", i, System.Threading.Thread.CurrentThread.GetHashCode()));
            System.Threading.Thread.Sleep(1000);
         }

      }

      
      public void ProgramMethod()
      {
         for (int i = 0; i < 5; i++)
         {
            Console.WriteLine( string.Format("Domain2: {0} thread id {1}", i, System.Threading.Thread.CurrentThread.GetHashCode()));
            System.Threading.Thread.Sleep(1000);
         }
         //throw new ArgumentException();
      }
   }
}
