using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting;

namespace RemotingClient
{
   public partial class Form1: Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      System.Runtime.Remoting.Channels.Http.HttpChannel m_channel = new System.Runtime.Remoting.Channels.Http.HttpChannel();

      protected override void OnClosing(CancelEventArgs e)
      {
         base.OnClosing(e);
         System.Runtime.Remoting.Channels.ChannelServices.UnregisterChannel(m_channel);
      }

      private void button1_Click(object sender, EventArgs e)
      {
         
         System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(m_channel, false);
      }

      WKO_Server.RemoteClass m_remoteObject;
      private void button2_Click(object sender, EventArgs e)
      {
         // SAO (WKO)

         // method 1
         //object remoteObject = Activator.GetObject(typeof(WKO_Server.RemoteClass), "http://localhost:13101/myurl.soap" );
         //m_remoteObject = (WKO_Server.RemoteClass)remoteObject;

         // method 2
         RemotingConfiguration.RegisterWellKnownClientType(typeof(WKO_Server.RemoteClass), "http://localhost:13101/myurl.soap");
         m_remoteObject = new WKO_Server.RemoteClass();
      
      }

      private void button4_Click(object sender, EventArgs e)
      {
         m_remoteObject.DoSomthing();
      }

      WKO_Server.RemoteClass rObject;
      private void button3_Click(object sender, EventArgs e)
      {
         // cao 
         RemotingConfiguration.RegisterActivatedClientType( typeof(WKO_Server.RemoteClass), "http://localhost:13101" );
         rObject = new WKO_Server.RemoteClass();
      }

      private void button5_Click(object sender, EventArgs e)
      {
         rObject.DoSomthing();
      }

   }
}