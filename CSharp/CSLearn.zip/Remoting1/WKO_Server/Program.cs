using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting;

namespace WKO_Server
{
   class Program
   {
      static void Main(string[] args)
      {
         System.Runtime.Remoting.Channels.Http.HttpChannel channel = new System.Runtime.Remoting.Channels.Http.HttpChannel(13101);
         System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(channel, false);

         RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteClass),
            "myurl.soap",
            WellKnownObjectMode.Singleton
         );

         Console.ReadKey();

         System.Runtime.Remoting.Channels.ChannelServices.UnregisterChannel(channel);
      }
   }

   public class RemoteClass: MarshalByRefObject
   {
      Guid m_objectGuid;
      public RemoteClass()
      {
         m_objectGuid = Guid.NewGuid();
         
         DisplayDetails("RemoteClass is up " );
      }
      public void DoSomthing()
      {
         DisplayDetails("RemoteClass.DoSomthing() called");
      }
      ~RemoteClass()
      {
         DisplayDetails("RemoteClass is down ");
      }

      void DisplayDetails(string message)
      {
         Console.WriteLine("{0} {1} Object={2:N} Thread={3} ", 
            message, 
            DateTime.Now.ToShortTimeString(), 
            m_objectGuid,
            System.Threading.Thread.CurrentThread.GetHashCode()
            );
      }

   }
}
