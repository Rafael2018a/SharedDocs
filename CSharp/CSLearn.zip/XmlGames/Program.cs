using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace XmlGames
{
   class Program
   {
      static void Main(string[] args)
      {
         //XmlDocument xDoc = new XmlDocument();
         //XmlNode rootElement = xDoc.CreateElement( "FileList" );
         //XmlDeclaration dec = xDoc.CreateXmlDeclaration( "1.0", "UTF-8", null );
         //xDoc.AppendChild( dec );
         //xDoc.AppendChild( rootElement );
         //xDoc.Save( "filelist.xml" );
         Program p = new Program();
         //         p.RemoveChild();
         //p.CreateNewXml();
         string s = p.BuildXString();
         //Console.ReadLine();

         string sq = DateTime.Now.ToString("R");
         DateTime dt = DateTime.Parse(sq);
      }

      string BuildXString()
      {
         XmlDocument xDoc = new XmlDocument();
         XmlElement rootElement = xDoc.CreateElement("Message");
         XmlAttribute att = xDoc.CreateAttribute("Type");
         att.Value = "MSUFileInfo";
         rootElement.Attributes.Append(att);

         XmlElement childElemet_filename = xDoc.CreateElement("Filename");
         childElemet_filename.InnerText = "myfile";

         XmlElement childElemet_timestamp = xDoc.CreateElement("Timestamp");
         childElemet_timestamp.InnerText = DateTime.Now.ToString("R");


         rootElement.AppendChild(childElemet_filename);
         rootElement.AppendChild(childElemet_timestamp);
         xDoc.AppendChild(rootElement);
         return xDoc.InnerXml;// InnerText;
      }

      void CreateNewXml()
      {
         XmlDocument xDoc = new XmlDocument();
         XmlNode xn = xDoc.CreateElement("log4j", "localname", "Elta");
         xDoc.AppendChild(xn);
      }
      void loadAndSave()
      {
         XmlDocument xDoc = new XmlDocument();
         try
         {
            xDoc.Load(@"..\..\Imtg_203041_7_16_0_A1_001.xml");
         }
         catch (FileNotFoundException ex)
         { Console.WriteLine(ex.Message); }

         XmlNode rootNode = xDoc.DocumentElement;
         XmlNode filenameNode = rootNode.SelectSingleNode("ImageId/FileName");
         Console.WriteLine(filenameNode.InnerText);
         filenameNode.InnerText = "value";
         xDoc.Save(@"..\..\Imtg_203041_7_16_0_A1_001.xml");

      }

      void RemoveChild()
      {
         XmlDocument xDoc = new XmlDocument();
         xDoc.Load("passedFiles.xml");
         XmlNode docElement = xDoc.DocumentElement;
         //XmlNode rootElem = docElement.FirstChild;
         string filename = "04_0000000003_OFR2_071205_052_0001_102222_221_R0.phx";
         string xpathExp = string.Format(@"/PassedFileList/Filename[.='{0}']", filename);
         XmlNodeList xNodeList = docElement.SelectNodes(xpathExp);
         //int m=xNodeList.Count;
         //for (int i=0; i<m; i++)
         foreach (XmlNode xnode in xNodeList)
         {
            docElement.RemoveChild(xnode);
         }
         xDoc.Save("taregt.xml");

      }
   }
}
