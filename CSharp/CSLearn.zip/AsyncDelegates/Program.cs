#define method4

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AsyncDelegates
{
   /// <summary>
   /// this class demonstrates 4 method of interacting with thrread called be delegates
   /// </summary>
   class Program
   {
      static void Main( string[] args )
      {
         Program p1 = new Program();
         Console.WriteLine( string.Format( "Main thread hash {0}", Thread.CurrentThread.GetHashCode() ) );
         Add_delegate add_DInst = new Add_delegate( p1.Add_DM );
#if !method4
         IAsyncResult asyncResult1 = add_dInst.BeginInvoke( 2, 2, null, null );
#else 
         IAsyncResult asyncResult1 = add_DInst.BeginInvoke( 2, 2, new AsyncCallback( p1.add_CompleteCallback ), "message to the callback" );
      
#endif
         int answer = -1;

         // Methods for waiting 
         //---------------------
#if method1 // wait (blocked!) until thread ends
         answer = add_dInst.EndInvoke( asyncResult1 );

#elif method2 // wait on flag
         while ( !asyncResult1.IsCompleted )
            Console.WriteLine( "Waiting..." );
         answer = add_dInst.EndInvoke( asyncResult1 );

#elif method3 // wait limited time
         // wait 100mS and no more
         if (asyncResult1.AsyncWaitHandle.WaitOne( 100, true ))
            answer = add_dInst.EndInvoke( asyncResult1 );
#endif
         Console.WriteLine( "Answer is " + answer.ToString() );
         Console.ReadLine();
      }

      delegate int Add_delegate( int a, int b );

      int Add_DM( int a, int b )
      {
         Console.WriteLine( string.Format( "Work thread hash {0}", Thread.CurrentThread.GetHashCode() ) );
         return a + b;
      }
#if method4 // the delegate calls this callback
      void add_CompleteCallback( IAsyncResult ar )
      {
         // should be the same as the work thread
         Console.WriteLine( string.Format( "CompleteCallback thread hash {0}", Thread.CurrentThread.GetHashCode() ) );

         // get the ancestor delegate instance
         System.Runtime.Remoting.Messaging.AsyncResult arObj = (System.Runtime.Remoting.Messaging.AsyncResult)ar;
         Add_delegate add_dInst_ = (Add_delegate)arObj.AsyncDelegate;

         int answer = add_dInst_.EndInvoke( ar );
         Console.WriteLine( "Answer is " + answer.ToString() );

         // message from main thread
         Console.WriteLine( (string)ar.AsyncState );
      }
#endif
   }
}
