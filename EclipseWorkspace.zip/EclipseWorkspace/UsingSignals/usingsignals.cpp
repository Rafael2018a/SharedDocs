

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cstdlib>
#include <queue>


using namespace std;

void handler(int signum)
{
  printf("\nSignal %d caught\n ", signum);
  exit(0);
}

int pushQueue()
{
   std::queue<string> myQ;
   string s = "hellostl";
   string s2;
   myQ.push(s);
   s2 = myQ.front();
   myQ.pop();
   cout << s2 << endl;
}

int main(int argc, char *argv[])
{
   
  pushQueue();
  exit(0);   
   
  struct sigaction sa;
  memset( &sa, 0, sizeof(sa));
  sa.sa_handler = &handler;
  sigaction(SIGINT, &sa, NULL);
  while(1)
  {
        //cout << "Hello, world!" << endl;
        sleep(1);
  }

  return EXIT_SUCCESS;
}

