/*
 * Main.cpp
 *
 *  Created on: Mar 29, 2009
 *      Author: Rafi
 */
#include <string>
#include <vector>
#include <iostream>
#include "Main.h"
using namespace std;
int main()
{
	Main m;
	m.Run();
	return 0;
}

Main::Main()
{
	// TODO Auto-generated constructor stub

}

Main::~Main()
{
	// TODO Auto-generated destructor stub
}

class Pair
{
public:
	int x;
	int y;
};

void f1( Pair pa)
{
 Pair * p;
 *p= pa;
 int z = (*p).x;
 (*p).x=124;
 cout << z;
}

void Main::Run()
{
	vector<Pair> v1;
	Pair p, *p2, p3;
	p.x=10; p.y=20;
	p2 = &p;
	p2->x=11;
	v1.push_back(p);
	v1[0].x=100; v1[0].y=200;

	//cout << p.x << endl;

	Pair pa;
	pa.x=123;
	f1( pa);
	int z = pa.x;
cout << z;

}

