/*
 * Main.h
 *
 *  Created on: Mar 29, 2009
 *      Author: Rafi
 */

#ifndef MAIN_H_
#define MAIN_H_

class Main
{
public:
	Main();
	virtual ~Main();
	void Run();
};

#endif /* MAIN_H_ */
