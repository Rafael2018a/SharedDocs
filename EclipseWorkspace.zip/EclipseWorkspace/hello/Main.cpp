/*
 * Main.cpp
 *
 *  Created on: Mar 23, 2009
 *      Author: Rafi
 */
#include <stdio.h>
#include <pthread.h>

int main()
{
	puts("hello eclipse\n");
	pthread_t t = pthread_self();
	printf("t: %d", (int)t);
 return 0;
}
