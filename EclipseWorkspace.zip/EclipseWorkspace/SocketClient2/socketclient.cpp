
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <cstdlib>

#include "cclient.h"
#include <string.h>
#include <signal.h>

#include "cfilereader.h"
using namespace std;

int main(int argc, char *argv[])
{
  CClient c;
  c.Run();
  CFileReader reader;
  //reader.Run();
  return EXIT_SUCCESS;
}


