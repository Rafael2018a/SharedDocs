#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "errno.h"
#include <queue>

#include "SignalHandler.h"
#include "cclient.h"



CClient::CClient()
{
        puts ( "client started" );
}

#ifdef DONT
void tmp()
{
   while (1)
   {
      bool rc = ConnectToServer();
      if (rc==1)
      {
         try
         {
            MessageLoop();
         }
         catch(...)
         {
            printf("Message loop break. %s\n", errorMessage);
            // Close socket
         }
      }
      else
      {
          perror("Connection to server failed. ");
          usleep(500000);
      }
   }


}
#endif
void CClient::Run()
{
        int localSocket_fd;
        socklen_t client_len;
        struct sockaddr_in client_address;
        int result;
        char buff[100];
        char rcvBuff[100];


        //string s1;

        SetSignal();

        localSocket_fd = socket ( AF_INET, SOCK_STREAM, 0 );
        client_address.sin_family = AF_INET;
        client_address.sin_addr.s_addr = inet_addr ( "127.0.0.1" );
        client_address.sin_port = 9876;
        client_len = sizeof ( client_address );


        result = connect ( localSocket_fd, ( struct sockaddr * ) &client_address, client_len );


        if ( result == -1 )
        {

                char * e = new char[100];
                e = strerror ( errno );
                puts ( e );
        }
        else
        {
                puts ( "client connected" );
                for ( char ch='a'; ch<'g'; ch++ )
                //char ch='k';
                {
                        memset ( buff, ch, 10 );

                        send ( localSocket_fd, buff, 10, 0 );

                        //write ( localSocket_fd, &ch, 1 );
                        //char ch1;
                        int len = recv ( localSocket_fd, rcvBuff, 10, 0 );

                        printf ( "Reply from server: %s\n", rcvBuff );
                        sleep ( 1 );
                }

                close ( localSocket_fd );

        }


        puts ( "client end" );

}


CClient::~CClient()
{
}


