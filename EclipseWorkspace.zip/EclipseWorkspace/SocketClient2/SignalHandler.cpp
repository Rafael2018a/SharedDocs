#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

int       m_sigpipe;
void SignalHandler ( int signum )
{
   puts ( "signal SIGPIPE accpted" );
   m_sigpipe=1;
   exit(0);
}
void SetSignal()
{
   struct sigaction sa;
   memset ( &sa, 0, sizeof ( sa ) );
   sa.sa_handler = &SignalHandler;
   sigaction ( SIGPIPE, &sa, NULL );
}
