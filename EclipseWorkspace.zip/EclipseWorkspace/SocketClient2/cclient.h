#ifndef CCLIENT_H
#define CCLIENT_H

#include <queue>

/**
	@author a <Rafi@localhost.localdomain>
*/
class CClient{
public:
    CClient();
    void Run();
    ~CClient();

    std::queue<int> m_inputQueue;

};

#endif
