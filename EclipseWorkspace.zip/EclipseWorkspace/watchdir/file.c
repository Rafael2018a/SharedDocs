line 1
line 2
[Rafi@localhost watchdir]$ touch file.a
[Rafi@localhost watchdir]$ mv file.b file.b1
[Rafi@localhost watchdir]$ mv file.b1 file.b
[Rafi@localhost watchdir]$ touch file.f


