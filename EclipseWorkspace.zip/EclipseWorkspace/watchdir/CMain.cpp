/*
 * CMain.cpp
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */
#include <iostream>
#include "IObserver.h"
#include "ISubject.h"
#include "CMain.h"
#include "CScout.h"
#include <string>
#include <pthread.h>
#include <sys/types.h>

#include "CProcessor_tc.h"
#include "CTransmit_tc.h"

using namespace std;

CMain::CMain() {
	// TODO Auto-generated constructor stub

}

CMain::~CMain() {
	// TODO Auto-generated destructor stub
}

CProcessor_tc m_processorObj;
CScout m_scoutObj;
CTransmit_tc m_transmitObj;

void CMain::Run()
{
	//scoutObj.UnitTest();
    key_t mqKey = 1221;

	m_scoutObj.RegisterInterest( this);

	pthread_t scThread = m_scoutObj.BeginThread();
	pthread_t tansmitThread = m_transmitObj.BeginThread( mqKey);
	pthread_t procThread = m_processorObj.BeginThread( mqKey);

	pthread_join( scThread, NULL);
	pthread_join( procThread, NULL);
	pthread_join( tansmitThread, NULL);
}


void CMain::Notify( string message)
{
 //printf("Main (observer) notified: %s\n", message);
 cout << "CMain (observer) notified:" << message << endl;
 m_processorObj.EnqueueItem( message);
}

void SendData(list<string> * slist)
{
	for( list<string>::iterator itr = slist->begin();
		 itr != slist->end();
		 itr++)
		cout <<  *itr ;
}

void CMain::UnitTest()
{
	CProcessor_tc * pr_p = new CProcessor_tc;
	string filename = "/home/Rafi/EclipseWorkspace/watchdir/file.c1";
	list<string> * p = pr_p->GetFileRows( &filename);
	SendData(p);
}

