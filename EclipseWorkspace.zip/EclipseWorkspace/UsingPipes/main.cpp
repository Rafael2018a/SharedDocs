/*
 * main.cpp
 *
 *  Created on: Mar 31, 2009
 *      Author: Rafi
 */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


#define pipeOutput 0
#define pipeInput 1

struct qmsg_t
{
	long mtype;
	char payload [32];
};

void MQReceiver()
{
	int rc=0;
	struct qmsg_t aMessage;

	int qid = msgget( (key_t)1236, 0666|IPC_CREAT);
	if (qid==-1)
		goto exit;

	{
		rc = msgrcv( qid, &aMessage, 32, 0, 0);
		if (rc==-1)
			goto exit;
		printf("Accepted message text: %s\n", aMessage.payload);
	}
	exit:return;
}
void MQSender()
{
	int rc=0;
	struct qmsg_t messageToSend;
	messageToSend.mtype=8;
	strcpy( messageToSend.payload, "here is the message");
	int qid = msgget( (key_t)1236, 0666|IPC_CREAT);
	if (qid<=1)
	{
		perror("");
		goto exit;
	}

	{
		rc = msgsnd( qid, (void*)&messageToSend, 32, 0);
		if (rc==-1)
		{
			perror("");
			goto exit;
		}

		puts("one message in q");

	}

	exit:return;
}
void UseMessageQueue()
{

	//MQSender();
	MQReceiver();


}

int main()
{
	UseMessageQueue();
	exit(0);

	int pipeVector [2];

	if (pipe( pipeVector) == 0)
	{
		int outFileDes = pipeVector[pipeOutput];
		int inFileDes = pipeVector[pipeInput];

		char message [] = "hello";
		int n = write( inFileDes, message, sizeof(message));

		char buffer [100];
		n = read( outFileDes, buffer, 100 );

		printf("%s %d\n", buffer, n);

	}

	return 0;
}



