/*
 * CTransmit_tc.cpp
 *
 *  Created on: Mar 30, 2009
 *      Author: Rafi
 */

#include <pthread.h>
#include <iostream>
#include <queue>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "CTransmit_tc.h"
#include "MessageQueue.h"

using namespace std;

CTransmit_tc::CTransmit_tc()
{
	// TODO Auto-generated constructor stub
}

CTransmit_tc::~CTransmit_tc()
{
	// TODO Auto-generated destructor stub
}

void * ThreadMethodWrapper1(void *caller)
{
	CTransmit_tc * t_p = (CTransmit_tc*) caller;
	t_p->CTransmit_ThreadMehod();
	return 0;
}

pthread_t CTransmit_tc::BeginThread(key_t inputMqKey)
{
	int rc = 0;

	// get mqid
	m_inputMqId = msgget(inputMqKey, 0666 | IPC_CREAT);
	if (m_inputMqId == -1)
	{
		perror("msgget fail. ");
		goto exit;
	}

	rc = pthread_create(&m_transmitThread, NULL, ThreadMethodWrapper1,
			(void*) this);
	if (rc != 0)
	{
		cout << "transmit thread creation failed" << endl;
		return 0;
	}

	exit: return m_transmitThread;
}

void CTransmit_tc::CTransmit_ThreadMehod()
{
	TextMessage_t acceptedMessage;

	while (1)
	{
		int rc = msgrcv(m_inputMqId, &acceptedMessage, MQ_PayloadSize,
				MQ_MessageType, 0);
		if (rc == -1)
		{
			perror("msgrcv fail. ");
			break;
		}

		printf("CTransmit_tc: %s", acceptedMessage.payload);
	}
	exit: return;
}


