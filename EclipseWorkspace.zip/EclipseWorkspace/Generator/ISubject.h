/*
 * ISubject.h
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#ifndef ISUBJECT_H_
#define ISUBJECT_H_

#include "IObserver.h"

class ISubject {

public:
  virtual void RegisterInterest(IObserver * observer) = 0;

};

#endif /* ISUBJECT_H_ */
