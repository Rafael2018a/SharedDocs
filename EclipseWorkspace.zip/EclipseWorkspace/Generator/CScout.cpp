/*
 * CScout.cpp
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#include <pthread.h>
#include <list>
#include <iostream>
#include <cstring>
#include <sys/stat.h>
#include <cstdlib>
#include <dirent.h>
#include "CScout.h"

using namespace std;

CScout::CScout()
{
	// TODO Auto-generated constructor stub
}

CScout::~CScout()
{
	// TODO Auto-generated destructor stub
}

void CScout::RegisterInterest(IObserver * observer_p)
{
	m_observersList.push_back(observer_p);
}

void * Scout_ThreadMehod_wrapper(void *caller)
{
	CScout * t_p = (CScout*) caller;
	t_p->Scout_ThreadMehod(NULL);
	return 0;
}

// main thread of Scout
void * CScout::Scout_ThreadMehod(void * p)
{
	string watchDir_absPath = "/home/Rafi/EclipseWorkspace/watchdir/";
	list<string> * existingList_p = NULL;
	list<string> * newList_p = NULL;

	puts("Scout_ThreadMehod started");
	printf("CScout: Watching dir %s\n", watchDir_absPath.c_str());

	while (1)
	{
		newList_p = GetFileEntriesList(watchDir_absPath);
		if (existingList_p == NULL)
			NotifyList(newList_p);
		else
		{
			list<string> * diffList_p = GetDiffList(existingList_p, newList_p);
			NotifyList(diffList_p);
			delete diffList_p;
		}
		delete existingList_p;
		existingList_p = newList_p;

		sleep(2);
	}

	return 0;
}

pthread_t CScout::BeginThread()
{

	int rc = pthread_create(&m_scoutThread, NULL, Scout_ThreadMehod_wrapper,
			(void*) this);
	if (rc != 0)
	{
		cout << "scout thread creation failed" << endl;
		return 0;
	}

	return m_scoutThread;
}

// Get sorted-list of items from newList which does not exist in existingList
list<string> * CScout::GetDiffList(list<string> *existingList_p,
		list<string> *newList_p)
{
	list<string> * diffList_p = new list<string> ;

	list<string>::iterator existItr = existingList_p->begin();
	for (list<string>::iterator newItr = newList_p->begin(); newItr
			!= newList_p->end(); newItr++)
	{
		if (FindItem(existingList_p, *newItr) == false)
			diffList_p->push_back(*newItr);

	}
	diffList_p->sort();
	return diffList_p;
}

bool CScout::NotifyList(list<string> *list_p)
{
	for (list<string>::iterator stringItr = list_p->begin(); stringItr
			!= list_p->end(); stringItr++)
	{
		for (list<IObserver*>::iterator itr = m_observersList.begin(); itr
				!= m_observersList.end(); itr++)

		{
			(*itr)->Notify(*stringItr);
			printf("CScout: New file notified %s\n", stringItr->c_str());
		}
	}
	return false;
}

// Get list of files from specified path, sorted.
list<string> * CScout::GetFileEntriesList(string fullPath)
{
	DIR *dir_p;
	struct dirent * dirEntry;
	struct stat statbuf;

	list<string> * list_p = new list<string> ;
	dir_p = opendir(fullPath.c_str());
	if (dir_p == NULL)
	{
		printf("Can't open dir %s", fullPath.c_str());
		goto exit;
	}
	chdir(fullPath.c_str());

	while ((dirEntry = readdir(dir_p)) != NULL)
	{
		lstat(dirEntry->d_name, &statbuf);
		if (S_ISREG (statbuf.st_mode))
		{
			list_p->push_back(dirEntry->d_name);

		}
	}
	list_p->sort();

	exit: return list_p;
}

bool CScout::FindItem(list<string> *list_p, string s)
{
	bool rc = false;

	for (list<string>::iterator itr = list_p->begin(); itr != list_p->end(); itr++)
	{
		if ((*itr) == s)
		{
			rc = true;
			break;
		}

	}
	return rc;
}

