/*
 * CScout.h
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#ifndef CSCOUT_H_
#define CSCOUT_H_

#include <vector>
#include <list>
#include <string>
#include "ISubject.h"

class CScout: public ISubject {
public:
	CScout();
	virtual ~CScout();
	virtual void RegisterInterest(IObserver * observer);
	pthread_t BeginThread();
	void UnitTest();
	void * Scout_ThreadMehod( void *);

private:
	list<IObserver*> m_observersList;
	pthread_t m_scoutThread;
	list<string> * GetFileEntriesList( string);
	bool NotifyList( list<string> *newList_p);
	list<string> *  GetDiffList( list<string> *newList_p, list<string> *existingList_p);
	bool FindItem( list<string> * existingList_p, string s);
};

#endif /* CSCOUT_H_ */
