/*
 * CProcessor_tc.h
 *
 *  Created on: Mar 30, 2009
 *      Author: Rafi
 */

#ifndef CPROCESSOR_TC_H_
#define CPROCESSOR_TC_H_

#include <string>
#include <pthread.h>
#include <queue>
#include <sys/types.h>


using namespace std;

class CProcessor_tc
{
public:
	CProcessor_tc();
	virtual ~CProcessor_tc();
	void EnqueueItem( string s);
	pthread_t BeginThread( key_t mqKey);
	void CProcessor_ThreadMehod();

private:
	pthread_t m_processorThread;
	queue<string> m_inputQ;
	pthread_mutex_t m_inputQ_mutex;
	string * GetNextItem();
	queue<string> * m_outputQ;
	int m_outputMqId;
	key_t m_mqKey;
	bool DeliverData( list<string> *);
public:
	list<string> * GetFileRows( string * fullFileName_p);


};

#endif /* CPROCESSOR_TC_H_ */
