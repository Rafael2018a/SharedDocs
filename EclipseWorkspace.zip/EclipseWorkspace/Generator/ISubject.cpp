/*
 * ISubject.cpp
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#include "ISubject.h"

