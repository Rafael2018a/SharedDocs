/*
 * CMain.h
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#ifndef CMAIN_H_
#define CMAIN_H_

#include "IObserver.h"

class CMain: public IObserver {
public:
	CMain();
	virtual ~CMain();
	void Run();
	void Notify( string message);
	void UnitTest( );
};

#endif /* CMAIN_H_ */
