/*
 * Main.cpp
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */
#include "IObserver.h"
#include "ISubject.h"
#include "CMain.h"

int main(int argc, char * argv[])
{
 CMain m;
 m.Run();

 puts("Program end\n");
 return 0;
}
