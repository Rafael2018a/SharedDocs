/*
 * CTransmit_tc.h
 *
 *  Created on: Mar 30, 2009
 *      Author: Rafi
 */

#ifndef CTRANSMIT_TC_H_
#define CTRANSMIT_TC_H_

#include <string>
#include <pthread.h>
#include <queue>
#include <sys/types.h>
#include "ISubject.h"

using namespace std;

class CTransmit_tc//: public ISubject
{
public:
	CTransmit_tc();
	virtual ~CTransmit_tc();
	void Run();
	void EnqueueItem(string s);
	pthread_t BeginThread( key_t mqKey);
	void CTransmit_ThreadMehod();
	queue<string>  GetInputQueue();
private:
	pthread_t m_transmitThread;
	queue<string> m_inputQ_p;
	//key_t m_mqKey;
	int m_inputMqId;
};

#endif /* CTRANSMIT_TC_H_ */
