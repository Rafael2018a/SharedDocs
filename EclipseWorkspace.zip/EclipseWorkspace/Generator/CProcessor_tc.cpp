/*
 * CProcessor_tc.cpp
 *
 *  Created on: Mar 30, 2009
 *      Author: Rafi
 */

#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>
#include <string>
#include <string.h>
#include <list>
#include "CProcessor_tc.h"
#include "MessageQueue.h"

CProcessor_tc::CProcessor_tc()
{
	pthread_mutex_init( &m_inputQ_mutex, NULL);
}

CProcessor_tc::~CProcessor_tc()
{
	// TODO Auto-generated destructor stub
}

void CProcessor_tc::EnqueueItem(string s)
{
	pthread_mutex_lock( &m_inputQ_mutex);
	m_inputQ.push( s);
	pthread_mutex_unlock( &m_inputQ_mutex);
}

bool CProcessor_tc::DeliverData(list<string> * slist)
{

	struct TextMessage_t aMessage;

	for( list<string>::iterator itr = slist->begin();
	     itr != slist->end();
	     itr++ )
	{
		strcpy( aMessage.payload, itr->c_str());
		aMessage.mtype=MQ_MessageType;
		int rc = msgsnd( m_outputMqId, (void*)&aMessage, (size_t)MQ_PayloadSize, 0);
		if (rc==-1)
			perror("CProcessor_tc: msgsnd failed. ");
	}
	return false;
}

void CProcessor_tc::CProcessor_ThreadMehod( )
{
	string * fullFilename_p;
	list<string> * rowsList_p;

    puts("CProcessor_tc::CProcessor_ThreadMehod started");

	m_outputMqId = msgget( m_mqKey, 0666|IPC_CREAT);
	if (m_outputMqId==-1)
	{
		perror("CProcessor_tc: msgget fail. Terminating thread.");
		goto exit;
	}

	while(1)
	{
		fullFilename_p = GetNextItem();

		if (fullFilename_p!=NULL)
		{
			cout << "CProcessor_tc: Got file: " << (*fullFilename_p) << endl;
			rowsList_p = GetFileRows( fullFilename_p );
			DeliverData( rowsList_p);
			delete rowsList_p;
			delete fullFilename_p;
		}
		else
			sleep(1);

	}

	exit: return;
}

void * ThreadMethodWrapper(void *caller)
{
	CProcessor_tc * t_p = (CProcessor_tc*) caller;
	t_p->CProcessor_ThreadMehod();
	return 0;
}


pthread_t CProcessor_tc::BeginThread( key_t mqKey)
{
	m_mqKey = mqKey;
	int rc = pthread_create(&m_processorThread, NULL, ThreadMethodWrapper, (void*) this);
	if (rc != 0)
	{
		cout << "scout thread creation failed" << endl;
		return 0;
	}

	return m_processorThread;

}

string * CProcessor_tc::GetNextItem()
{
	string * resutItem=NULL;

	pthread_mutex_lock( &m_inputQ_mutex);
	if (m_inputQ.size()>0)
	{
		resutItem = new string( m_inputQ.front());
		m_inputQ.pop();
	}
	pthread_mutex_unlock( &m_inputQ_mutex);

	return resutItem;
}


// Open a text file and return its rows as list of strings. Return NULL in
// case of error. caller should free returned list.
list<string> * CProcessor_tc::GetFileRows(string *fullFileName_p)
{
	list<string> * slist = NULL;

	FILE * file_p = fopen( fullFileName_p->c_str(), "r");
	if (file_p!=NULL)
	{
		slist = new list<string>;
		char  tempBuff [512];
		while (fgets( tempBuff, 512, file_p) != NULL)
		{
			slist->push_back( tempBuff);
		}
	}
	else
		cout << "failed to open file " <<  fullFileName_p->c_str() << ". " << strerror(errno) <<  endl;

	return slist;
}






