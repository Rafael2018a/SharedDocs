/*
 * MessageQueue.h
 *
 *  Created on: Apr 1, 2009
 *      Author: Rafi
 */

#ifndef MESSAGEQUEUE_H_
#define MESSAGEQUEUE_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MQ_PayloadSize 256
#define MQ_MessageType 9
struct TextMessage_t
{
	long mtype;
	char payload [MQ_PayloadSize];
};




#endif /* MESSAGEQUEUE_H_ */
