/*
 * IObserver.h
 *
 *  Created on: Mar 26, 2009
 *      Author: Rafi
 */

#ifndef IOBSERVER_H_
#define IOBSERVER_H_

#include <string>
using namespace std;

class IObserver {
public:
	virtual void Notify( string message) = 0;
};

#endif /* IOBSERVER_H_ */
