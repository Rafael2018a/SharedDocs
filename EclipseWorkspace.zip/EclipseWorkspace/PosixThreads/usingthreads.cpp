/***************************************************************************
 *   Copyright (C) 2009 by A   *
 *   Rafi@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

using namespace std;

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condVar1;// = PTHREAD_COND_INITIALIZER;
bool terminateThread_flag = false;

void * thread_function( void *arg)
{
   printf("thread_function: %s\n", (char*)arg);
    int loopCount = 1;

   for(int i=0;i<1000;i++)
   {
	   if (terminateThread_flag==true)
	     break;//pthread_exit(0);
      //pthread_mutex_lock( &mutex1);
      pthread_cond_wait( &condVar1, &mutex1);
      //puts("pthread_cond_wait( &condVar1, &mutex1);");
      pthread_mutex_unlock( &mutex1);
      //puts("pthread_mutex_unlock( &mutex1); @threadFunction");

	   if (terminateThread_flag==true)
	     break;//pthread_exit(0);

      printf("a=%d", loopCount++);
      //fflush( stdout);

   }

   puts("terminating thread ... ");
   return 0;
   //pthread_exit((void*)"thread exit");

}

char message[] = "thread start";


void UseThreads()
{
   int rc;
   pthread_t aThread;
   void * threadResult;
   //pthread_t currentThreadId;

   rc = pthread_mutex_init( &mutex1, NULL);
   if (rc!=0)
   {
      perror("semaphore init failed");
      goto exit;
   }
   rc = pthread_cond_init( &condVar1, NULL);
   if (rc!=0)
   {
      perror("cond-var init failed");
      goto exit;
   }

   //currentThreadId = pthread_self();
   rc = pthread_create( &aThread, NULL, thread_function, (void*)message);
   usleep(100);
   if (rc==0)
   {
      for(int i=0;i<3;i++)
      {
          pthread_mutex_lock( &mutex1);
          //puts("pthread_mutex_lock( &mutex1)");
          pthread_cond_signal( &condVar1);
          //puts("pthread_cond_signal( &condVar1)");
          pthread_mutex_unlock( &mutex1);
          //puts("pthread_mutex_unlock( &mutex1) @useThreads");
         sleep(1);
      }
      terminateThread_flag = true;
      pthread_mutex_lock( &mutex1);
      //puts("pthread_mutex_lock( &mutex1)");
      pthread_cond_signal( &condVar1);
      //puts("pthread_cond_signal( &condVar1)");
      pthread_mutex_unlock( &mutex1);
      //puts("pthread_mutex_unlock( &mutex1) @useThreads");

      pthread_join( aThread, &threadResult);
      goto exit;
   }
   else
      perror("thread creation failed");

   exit: return;


}

int main(int argc, char *argv[])
{
  cout << "UsingThread start" << endl;

  UseThreads();

  puts("Program end");
  return EXIT_SUCCESS;

#ifdef _REENTRANT
  //rafi rai;
#endif
}
